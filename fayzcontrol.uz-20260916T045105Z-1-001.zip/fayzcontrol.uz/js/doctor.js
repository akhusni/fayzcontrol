/**
 * FAYZ MEDICAL HOUSE — DOCTOR'S POST & CLINICAL EMR ENGINE
 * Full clinical patient history, 206-drug prescriber (List Naznacheniy),
 * examination diary (dnevnik obxoda), and official discharge recommendations.
 */

(function () {
  'use strict';

  // Default Patient Dataset (Clean empty state)
  const DEFAULT_PATIENTS = [];

  // Clinic Doctor Profiles (Synced with data/users.json and MySQL staff table)
  const CLINIC_DOCTORS = [
    {
      username: 'dr_bobur',
      password: 'docbobur2026',
      staff_id: 'STF-DOC-01',
      name: 'Dr. Bobur Mirzayev',
      role: 'Bosh Shifokor / Narkolog-Psixiatr',
      specialty: 'Narkologiya va Psixiatriya',
      avatar: '👨‍⚕️'
    },
    {
      username: 'dr_jasur',
      password: 'docjasur2026',
      staff_id: 'STF-DOC-02',
      name: 'Dr. Jasur Aliyev',
      role: 'Shifokor Narkolog',
      specialty: 'Narkologiya va Reanimatologiya',
      avatar: '👨‍⚕️'
    },
    {
      username: 'dr_dilnoza',
      password: 'docdilnoza2026',
      staff_id: 'STF-DOC-03',
      name: 'Dr. Dilnoza Rahimova',
      role: 'Psixiatr-Psixoterapevt',
      specialty: 'Psixiatriya va Psixoterapiya',
      avatar: '👩‍⚕️'
    }
  ];

  // Master State
  const state = {
    doctors: [],
    authenticatedDoctor: null,
    activeDoctorId: '',
    patients: [],
    filteredPatients: [],
    selectedPatient: null,
    pharmacology: [],
    anamnesisMap: {},
    prescriptionsMap: {},
    dailyNotesMap: {},
    currentFilter: 'all',
    searchQuery: '',
    activeTab: 'anamnesis',
    currentTheme: localStorage.getItem('fmh_theme') || 'night',
    newCase: {
      step: 1,
      intakeType: 'outpatient',
      prescriptions: []
    }
  };

  const STORAGE_KEYS = {
    THEME: 'fmh_theme',
    ANAMNESIS: 'FMH_ANAMNESIS_STORAGE_V2',
    PRESCRIPTIONS: 'FMH_PRESCRIPTIONS_STORAGE_V2',
    DAILY_NOTES: 'FMH_DAILY_NOTES_STORAGE_V2',
    ACTIVE_DOCTOR: 'fmh_active_doctor'
  };

  // Toast Notification Helper (Minimal, non-intrusive)
  function showToast(message, type = 'success') {
    let container = document.getElementById('fmh-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'fmh-toast-container';
      container.style.cssText = 'position: fixed; top: 24px; right: 24px; z-index: 999999; display: flex; flex-direction: column; gap: 8px; pointer-events: none;';
      document.body.appendChild(container);
    }

    // Keep max 1 active toast at a time to eliminate clutter
    container.innerHTML = '';

    const toast = document.createElement('div');
    const bg = type === 'danger' 
      ? 'rgba(225, 29, 72, 0.92)' 
      : (type === 'warning' ? 'rgba(217, 119, 6, 0.92)' : (type === 'info' ? 'rgba(2, 132, 199, 0.92)' : 'rgba(16, 185, 129, 0.92)'));
    toast.style.cssText = `background: ${bg}; color: #ffffff; padding: 10px 16px; border-radius: 8px; font-family: 'Outfit', sans-serif; font-size: 0.84rem; font-weight: 600; box-shadow: 0 8px 20px rgba(0,0,0,0.25); display: flex; align-items: center; gap: 8px; pointer-events: auto; transition: opacity 0.2s ease;`;
    toast.innerHTML = message;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 200);
    }, 1800);
  }

  // =========================================================================
  // THEME ENGINE (DAY MODE ☀️ / NIGHT MODE 🌙)
  // =========================================================================
  function applyTheme(theme) {
    if (window.FMH_Theme) {
      window.FMH_Theme.set(theme);
      state.currentTheme = window.FMH_Theme.get();
      return;
    }
    state.currentTheme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    document.body.className = `doctor-portal ${theme}-mode`;
    localStorage.setItem(STORAGE_KEYS.THEME, theme);

    const toggleBtn = document.getElementById('doctor-theme-toggle');
    if (toggleBtn) {
      if (theme === 'day') {
        toggleBtn.innerHTML = '<i class="fas fa-moon" style="color: #6366f1;"></i> <span>Tungi</span>';
        toggleBtn.title = "Tungi rejimga o'tish";
      } else {
        toggleBtn.innerHTML = '<i class="fas fa-sun" style="color: #fbbf24;"></i> <span>Kunduzgi</span>';
        toggleBtn.title = "Kunduzgi rejimga o'tish";
      }
    }
  }

  function toggleTheme() {
    if (window.FMH_Theme) {
      window.FMH_Theme.toggle();
      state.currentTheme = window.FMH_Theme.get();
      return;
    }
    const nextTheme = state.currentTheme === 'day' ? 'night' : 'day';
    applyTheme(nextTheme);
  }

  // =========================================================================
  // INITIALIZATION & DATA LOADING
  // =========================================================================
  async function init() {
    applyTheme(state.currentTheme);
    checkDoctorAuth();
    updateDoctorIdentityDisplay();
    setupEventListeners();

    // Instant render with default data so UI is NEVER empty
    filterPatients('all');
    if (state.patients.length > 0) {
      selectPatient(state.patients[0]);
    }

    // Async load API data from MySQL without blocking UI
    try { await loadStaffDatabase(); } catch (e) { console.warn(e); }
    try { await loadPharmacologyDatabase(); } catch (e) { console.warn(e); }
    try { await loadPatientDatabase(); } catch (e) { console.warn(e); }
    try { await loadClinicalRecords(); } catch (e) { console.warn(e); }

    // Check URL hash / query param for pre-selected patient or new consultation
    const urlParams = new URLSearchParams(window.location.search);
    const targetPatientId = urlParams.get('patient') || urlParams.get('id');
    if (targetPatientId) {
      const match = state.patients.find(p => p.id === targetPatientId || p.patient_code === targetPatientId);
      if (match) selectPatient(match);
    }
    if (urlParams.get('action') === 'new_consultation' || window.location.hash === '#new-case') {
      setTimeout(() => openNewConsultationModal(), 350);
    }

    updateKPIs();

    // Auto-refresh every 10s
    setInterval(async () => {
      try {
        await loadPatientDatabase();
        updateKPIs();
      } catch (err) {}
    }, 10000);

    window.addEventListener('storage', (e) => {
      if (e.key === 'FMH_FACILITY_14BEDS_STORAGE_V18' || e.key === 'FMH_PATIENTS_V1') {
        loadPatientDatabase();
        updateKPIs();
      }
    });
  }

  async function loadStaffDatabase() {
    try {
      const res = await fetch('/api/staff');
      if (res.ok) {
        const staffList = await res.json();
        const docs = staffList.filter(s => 
          (s.role === 'doctor' || s.role === 'chief_doctor' || (s.specialty && s.specialty.trim() !== '') || s.full_name.toLowerCase().includes('dr'))
        ).map(s => ({
          id: s.id,
          name: s.full_name,
          title: s.specialty || s.role || 'Shifokor',
          phone: s.phone || ''
        }));
        state.doctors = docs;
        if (state.authenticatedDoctor) {
          const match = docs.find(d => d.id === state.authenticatedDoctor.staff_id || d.name.toLowerCase().includes(state.authenticatedDoctor.name.toLowerCase()));
          if (match) {
            state.activeDoctorId = match.id;
          }
        } else if (docs.length > 0 && !state.activeDoctorId) {
          state.activeDoctorId = docs[0].id;
        }
        updateDoctorIdentityDisplay();
      }
    } catch (e) {
      console.warn("Could not load /api/staff", e);
    }
  }

  async function loadPharmacologyDatabase() {
    try {
      const res = await fetch('./data/pharmacology_db.json');
      const data = await res.json();
      state.pharmacology = data.medications || [];
      // Normalize
      state.pharmacology.forEach(m => {
        if (!m.name) m.name = m.trade_name_uz || m.trade_name || m.inn || 'Dori';
        if (!m.form) m.form = m.dosage_form || 'Tabletkalar';
      });
      populateDrugDataList();
      console.log(`[DoctorWorkstation] Loaded ${state.pharmacology.length} medications into prescription engine.`);
    } catch (err) {
      console.warn("Could not load pharmacology_db.json via fetch, trying fayz_house_meds.json", err);
      try {
        const res2 = await fetch('./data/fayz_house_meds.json');
        const data2 = await res2.json();
        state.pharmacology = data2.medications || [];
        populateDrugDataList();
      } catch (err2) {
        console.warn("Fallback medications used", err2);
      }
    }
  }

  function populateDrugDataList() {
    let datalist = document.getElementById('rx-medications-datalist');
    if (!datalist) {
      datalist = document.createElement('datalist');
      datalist.id = 'rx-medications-datalist';
      document.body.appendChild(datalist);
    }
    const sorted = [...state.pharmacology].sort((a, b) => {
      if (a.fayz_house_list && !b.fayz_house_list) return -1;
      if (!a.fayz_house_list && b.fayz_house_list) return 1;
      return (a.fayz_house_num || 999) - (b.fayz_house_num || 999);
    });

    const options = [];
    sorted.forEach(m => {
      const numPrefix = m.fayz_house_num ? `[№${m.fayz_house_num}] ` : '';
      const badge = m.prescription_type === 'Rx_Strict_Psychotropic' ? ' ⚠️ (Psixotrop)' : '';
      options.push(`<option value="${m.name}">${numPrefix}${m.inn ? m.inn + ' • ' : ''}${m.form || ''}${badge}</option>`);
      if (m.paper_name && m.paper_name !== m.name) {
        options.push(`<option value="${m.paper_name}">${numPrefix}${m.name} • ${m.form || ''}${badge}</option>`);
      }
    });
    datalist.innerHTML = options.join('');
  }

  async function loadPatientDatabase() {
    try {
      const res = await fetch('/api/patients');
      if (res.ok) {
        const livePatients = await res.json();
        if (Array.isArray(livePatients)) {
          state.patients = livePatients;
          filterPatients(state.currentFilter);
          if (state.patients.length > 0) {
            const match = state.selectedPatient ? state.patients.find(p => p.id === state.selectedPatient.id) : null;
            if (!match) {
              selectPatient(state.patients[0]);
            } else {
              state.selectedPatient = match;
            }
          } else {
            state.selectedPatient = null;
            renderEmptyWorkstation();
          }
        }
      }
    } catch (e) {
      console.warn("Could not load /api/patients", e);
    }
  }

  async function loadClinicalRecords() {
    // 1. Anamnesis
    const savedAnamnesis = localStorage.getItem(STORAGE_KEYS.ANAMNESIS);
    if (savedAnamnesis) {
      try { state.anamnesisMap = JSON.parse(savedAnamnesis); } catch (e) {}
    }

    // 2. Prescriptions
    const savedRx = localStorage.getItem(STORAGE_KEYS.PRESCRIPTIONS);
    if (savedRx) {
      try { state.prescriptionsMap = JSON.parse(savedRx); } catch (e) {}
    }

    // 3. Daily Notes
    const savedNotes = localStorage.getItem(STORAGE_KEYS.DAILY_NOTES);
    if (savedNotes) {
      try { state.dailyNotesMap = JSON.parse(savedNotes); } catch (e) {}
    }
  }

  // =========================================================================
  // PATIENT SELECTION & FILTERING
  // =========================================================================
  function filterPatients(filterType = 'all') {
    state.currentFilter = filterType;
    document.querySelectorAll('.doc-pill-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-filter') === filterType);
    });

    // Update dynamic count badges on filter pills
    const allCount = state.patients.length;
    const inpatientsCount = state.patients.filter(p => p.status === 'active' && p.active_admission).length;
    const outpatientsCount = state.patients.filter(p => p.status !== 'active' || !p.active_admission).length;
    const allergyCount = state.patients.filter(p => p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q' && p.medical_allergies.trim() !== '').length;

    const activeDoc = state.authenticatedDoctor || state.doctors.find(d => d.id === state.activeDoctorId);
    const docName = activeDoc ? activeDoc.name.toLowerCase() : '';
    const docId = (state.authenticatedDoctor && state.authenticatedDoctor.staff_id) || state.activeDoctorId;
    const myCount = state.patients.filter(p => {
      const pDocId = p.doctor_id || (p.active_admission && p.active_admission.doctor_id) || p.consulting_doctor_id;
      const pDocName = (p.doctor_name || (p.active_admission && p.active_admission.doctor_name) || p.consulting_doctor_name || '').toLowerCase();
      return (docId && pDocId === docId) || (docName && pDocName.includes(docName));
    }).length;

    const elAll = document.getElementById('cnt-all');
    const elIn = document.getElementById('cnt-inpatient');
    const elMy = document.getElementById('cnt-my');
    const elAllergy = document.getElementById('cnt-allergy');
    const elOut = document.getElementById('cnt-outpatient');
    if (elAll) elAll.textContent = allCount;
    if (elIn) elIn.textContent = inpatientsCount;
    if (elMy) elMy.textContent = myCount;
    if (elAllergy) elAllergy.textContent = allergyCount;
    if (elOut) elOut.textContent = outpatientsCount;

    // Toggle search clear button
    const clearBtn = document.getElementById('btn-clear-search');
    if (clearBtn) {
      clearBtn.style.display = state.searchQuery ? 'block' : 'none';
    }

    let list = [...state.patients];

    if (filterType === 'inpatient') {
      list = list.filter(p => p.status === 'active' && p.active_admission);
    } else if (filterType === 'outpatient') {
      list = list.filter(p => p.status !== 'active' || !p.active_admission);
    } else if (filterType === 'my_patients') {
      list = list.filter(p => {
        const pDocId = p.doctor_id || (p.active_admission && p.active_admission.doctor_id) || p.consulting_doctor_id;
        const pDocName = (p.doctor_name || (p.active_admission && p.active_admission.doctor_name) || p.consulting_doctor_name || '').toLowerCase();
        return (docId && pDocId === docId) || (docName && pDocName.includes(docName));
      });
    } else if (filterType === 'allergy') {
      list = list.filter(p => p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q' && p.medical_allergies.trim() !== '');
    }

    if (state.searchQuery) {
      const q = state.searchQuery.toLowerCase();
      list = list.filter(p => 
        p.full_name.toLowerCase().includes(q) ||
        p.patient_code.toLowerCase().includes(q) ||
        (p.phone && p.phone.includes(q)) ||
        (p.active_admission && p.active_admission.bed_code && p.active_admission.bed_code.toLowerCase().includes(q)) ||
        (p.active_admission && p.active_admission.room_number && p.active_admission.room_number.includes(q)) ||
        (p.diagnosis && p.diagnosis.toLowerCase().includes(q)) ||
        (p.primary_diagnosis && p.primary_diagnosis.toLowerCase().includes(q)) ||
        (p.icd10_code && p.icd10_code.toLowerCase().includes(q))
      );
    }

    const oldData = state.filteredPatients ? JSON.stringify(state.filteredPatients) : null;
    const newData = JSON.stringify(list);
    
    if (oldData !== newData) {
      state.filteredPatients = list;
      const container = document.getElementById('doctor-patient-list');
      const scrollPos = container ? container.scrollTop : 0;
      
      renderPatientList();
      
      if (container) {
        requestAnimationFrame(() => {
          container.scrollTop = scrollPos;
        });
      }
    } else {
      state.filteredPatients = list;
    }
  }

  function clearSearch() {
    const input = document.getElementById('doctor-patient-search');
    if (input) input.value = '';
    state.searchQuery = '';
    const clearBtn = document.getElementById('btn-clear-search');
    if (clearBtn) clearBtn.style.display = 'none';
    filterPatients(state.currentFilter);
  }

  function renderPatientList() {
    const container = document.getElementById('doctor-patient-list');
    if (!container) return;

    if (state.filteredPatients.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 2rem 1rem; color: var(--text-muted); font-size: 0.85rem;">
          <i class="fas fa-search" style="font-size: 1.5rem; margin-bottom: 8px; opacity: 0.5;"></i>
          <div>Hech qanday bemor topilmadi</div>
        </div>
      `;
      return;
    }

    container.innerHTML = state.filteredPatients.map(p => {
      const isSelected = state.selectedPatient && state.selectedPatient.id === p.id;
      const bedStr = p.active_admission ? `${p.active_admission.room_number}-xona ${p.active_admission.bed_code}` : 'Ambulator';
      const hasAllergy = p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q' && p.medical_allergies.trim() !== '';

      const bp = p.latest_vitals ? `${p.latest_vitals.vital_bp_systolic}/${p.latest_vitals.vital_bp_diastolic}` : '120/80';
      const pulse = p.latest_vitals ? p.latest_vitals.vital_pulse : '72';
      const spo2 = p.latest_vitals ? `${p.latest_vitals.vital_spo2}%` : '99%';

      const notes = state.dailyNotesMap[p.id] || [];
      const condition = notes.length > 0 ? notes[0].condition : 'satisfactory';
      let statusClass = '';
      if (condition === 'moderate') statusClass = 'status-moderate';
      else if (condition === 'severe' || condition === 'critical') statusClass = 'status-critical';

      let dayCounterStr = '';
      if (p.active_admission && p.active_admission.admission_date) {
        const adDate = new Date(p.active_admission.admission_date);
        const today = new Date();
        const diffMs = today - adDate;
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24)) + 1;
        if (diffDays > 0) {
          dayCounterStr = `<span class="day-counter-badge" style="margin-left:6px; font-size:0.75rem; background:var(--bg-lighter); padding:2px 6px; border-radius:12px;">Day ${diffDays}</span>`;
        }
      }

      const diag = p.diagnosis || p.primary_diagnosis || '';
      const diagStr = diag.length > 40 ? diag.substring(0, 40) + '...' : diag;
      const diagHtml = diagStr ? `<div class="doc-pt-diagnosis" style="font-size:0.8rem; color:var(--text-secondary); margin-top:4px;"><i>${diagStr}</i></div>` : '';

      return `
        <div class="doc-patient-card ${isSelected ? 'active' : ''} ${statusClass}" onclick="window.FMH_Doctor.selectPatientById('${p.id}')">
          <div class="doc-pt-top">
            <div class="doc-pt-name">${p.full_name} ${dayCounterStr}</div>
            <span class="doc-bed-tag">${bedStr}</span>
          </div>
          <div class="doc-pt-details">
            <span><i class="fas fa-id-badge"></i> ${p.patient_code}</span> • 
            <span>${p.birth_year ? (2026 - p.birth_year) + ' yosh' : 'N/A'}</span>
          </div>
          ${diagHtml}
          <div class="doc-pt-vitals">
            <span><i class="fas fa-heartbeat"></i> ${bp} mm</span>
            <span>• ${pulse} bpm</span>
            <span>• SpO2 ${spo2}</span>
          </div>
          ${hasAllergy ? `
            <div class="doc-pt-allergy-alert">
              <i class="fas fa-exclamation-triangle"></i> Allergiya: ${p.medical_allergies}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');
  }

  async function selectPatient(patient) {
    state.selectedPatient = patient;
    renderPatientList();
    renderWorkstation();

    // Fetch live clinical records from MySQL DB
    try {
      const res = await fetch(`/api/doctor/clinical/${patient.id}`);
      if (res.ok) {
        const bundle = await res.json();
        if (bundle.anamnesis) {
          state.anamnesisMap[patient.id] = bundle.anamnesis;
        }
        if (bundle.prescriptions && bundle.prescriptions.length > 0) {
          state.prescriptionsMap[patient.id] = bundle.prescriptions;
        }
        if (bundle.daily_notes && bundle.daily_notes.length > 0) {
          state.dailyNotesMap[patient.id] = bundle.daily_notes;
        }
        if (bundle.discharge_epicrisis) {
          if (!state.epicrisisMap) state.epicrisisMap = {};
          state.epicrisisMap[patient.id] = bundle.discharge_epicrisis;
        }
        renderWorkstation();
      }
    } catch (e) {
      console.warn("Could not fetch clinical bundle from MySQL API", e);
    }
  }

  function selectPatientById(id) {
    const p = state.patients.find(item => item.id === id || item.patient_code === id);
    if (p) selectPatient(p);
  }

  // =========================================================================
  // CLINICAL WORKSTATION RENDERING & LOGIC
  // =========================================================================
  function renderEmptyWorkstation() {
    const emptyView = document.getElementById('empty-workstation-view');
    const vitalsDash = document.getElementById('ws-vitals-dashboard');
    const jumpStrip = document.getElementById('ws-quick-jump-strip');
    if (emptyView) emptyView.style.display = 'flex';
    if (vitalsDash) vitalsDash.style.display = 'none';
    if (jumpStrip) jumpStrip.style.display = 'none';

    // hide tab panes and badges
    document.querySelectorAll('.ws-tab-pane').forEach(el => el.classList.remove('active'));
    ['tab-badge-rx', 'tab-badge-notes'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });

    const avatarEl = document.getElementById('ws-patient-avatar');
    const nameEl = document.getElementById('ws-patient-name');
    const metaEl = document.getElementById('ws-patient-meta');

    if (avatarEl) avatarEl.textContent = '—';
    if (nameEl) nameEl.textContent = "Bemor Tanlanmagan";
    if (metaEl) {
      metaEl.innerHTML = `
        <span style="color: var(--text-muted); font-size: 0.85rem;">
          <i class="fas fa-info-circle"></i> Chap paneldan bemor kartasini tanlang yoki yangi konsultatsiya oching.
        </span>
      `;
    }

    const allergyBanner = document.getElementById('ws-allergy-banner');
    if (allergyBanner) allergyBanner.style.display = 'none';
  }

  function quickJump(tabName) {
    switchTab(tabName);
    if (tabName === 'diary') {
      const el = document.getElementById('note-dynamics');
      if (el) el.focus();
    } else if (tabName === 'prescriptions') {
      const el = document.getElementById('rx-drug-name');
      if (el) el.focus();
    } else if (tabName === 'anamnesis') {
      const el = document.getElementById('anam-complaints');
      if (el) el.focus();
    } else if (tabName === 'epicrisis') {
      const el = document.getElementById('epicrisis-home-rx');
      if (el) el.focus();
    }
  }

  function updateVitalsDashboard() {
    const dashboard = document.getElementById('ws-vitals-dashboard');
    if (!dashboard) return;

    const p = state.selectedPatient;
    if (!p) {
      dashboard.style.display = 'none';
      return;
    }

    const notes = state.dailyNotesMap[p.id] || [];
    if (notes.length === 0) {
      dashboard.style.display = 'none';
      return;
    }

    dashboard.style.display = 'grid';
    
    const latestNote = notes[0];
    const bp = latestNote.bp || '120/80';
    const pulse = latestNote.pulse || 72;
    const temp = latestNote.temp || 36.6;
    const spo2 = latestNote.spo2 || 98;
    const condition = latestNote.condition || 'satisfactory';

    const bpEl = document.getElementById('vital-bp-val');
    const pulseEl = document.getElementById('vital-pulse-val');
    const tempEl = document.getElementById('vital-temp-val');
    const spo2El = document.getElementById('vital-spo2-val');
    const conditionEl = document.getElementById('vital-condition-val');

    if (bpEl) bpEl.textContent = bp;
    if (pulseEl) pulseEl.textContent = pulse;
    if (tempEl) tempEl.textContent = temp;
    if (spo2El) spo2El.textContent = spo2;

    if (conditionEl) {
      const condMap = {
        satisfactory: 'Qoniqarli',
        moderate: 'O\'rta og\'ir',
        severe: 'Og\'ir',
        critical: 'Kritik'
      };
      conditionEl.textContent = condMap[condition] || condition;
    }

    const setClass = (el, val, type) => {
      if (!el) return;
      el.className = '';
      if (type === 'pulse') {
        if (val > 120) el.classList.add('vital-critical');
        else if (val > 100) el.classList.add('vital-elevated');
        else el.classList.add('vital-normal');
      } else if (type === 'temp') {
        if (val > 38.5) el.classList.add('vital-critical');
        else if (val > 37.5) el.classList.add('vital-elevated');
        else el.classList.add('vital-normal');
      } else if (type === 'spo2') {
        if (val < 90) el.classList.add('vital-critical');
        else if (val < 95) el.classList.add('vital-elevated');
        else el.classList.add('vital-normal');
      }
    };

    setClass(pulseEl, pulse, 'pulse');
    setClass(tempEl, temp, 'temp');
    setClass(spo2El, spo2, 'spo2');
  }

  function updateTabBadges() {
    const p = state.selectedPatient;
    if (!p) return;

    const rxCount = (state.prescriptionsMap[p.id] || []).length;
    const rxBadge = document.getElementById('tab-badge-rx');
    if (rxBadge) {
      rxBadge.textContent = rxCount;
      rxBadge.style.display = rxCount > 0 ? 'inline-flex' : 'none';
    }

    const notesCount = (state.dailyNotesMap[p.id] || []).length;
    const notesBadge = document.getElementById('tab-badge-notes');
    if (notesBadge) {
      notesBadge.textContent = notesCount;
      notesBadge.style.display = notesCount > 0 ? 'inline-flex' : 'none';
    }
  }

  function renderWorkstation() {
    const p = state.selectedPatient;
    if (!p) {
      renderEmptyWorkstation();
      return;
    }

    const emptyView = document.getElementById('empty-workstation-view');
    const jumpStrip = document.getElementById('ws-quick-jump-strip');
    if (emptyView) emptyView.style.display = 'none';
    if (jumpStrip) jumpStrip.style.display = 'flex';
    
    // Switch to active tab or default to anamnesis
    switchTab(state.activeTab || 'anamnesis');

    updateVitalsDashboard();
    updateTabBadges();

    // Set today date in Diary
    const dateEl = document.getElementById('diary-today-date');
    if (dateEl) {
      const now = new Date();
      dateEl.textContent = 'Bugun: ' + now.toLocaleDateString('uz-UZ', { year: 'numeric', month: 'long', day: 'numeric' });
    }

    // Header info
    const avatarEl = document.getElementById('ws-patient-avatar');
    const nameEl = document.getElementById('ws-patient-name');
    const metaEl = document.getElementById('ws-patient-meta');

    if (avatarEl) {
      const initials = p.full_name.replace('Bemor ', '').split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'PT';
      avatarEl.textContent = initials;
    }
    if (nameEl) nameEl.textContent = p.full_name;
    if (metaEl) {
      const age = p.birth_year ? `${2026 - p.birth_year} yosh` : 'N/A';
      const gender = p.gender === 'female' ? 'Ayol' : 'Erkak';
      const bed = p.active_admission ? `${p.active_admission.room_number}-xona (${p.active_admission.bed_code} karavot)` : 'Ambulator';
      const program = p.active_admission ? p.active_admission.program_type.toUpperCase() : 'STANDART';

      let dayCounterStr = '';
      if (p.active_admission && p.active_admission.admission_date) {
        const adDate = new Date(p.active_admission.admission_date);
        const today = new Date();
        const diffDays = Math.max(1, Math.floor((today - adDate) / (1000 * 60 * 60 * 24)) + 1);
        dayCounterStr = `<span class="day-counter-badge" style="margin-left:4px;"><i class="fas fa-clock"></i> ${diffDays}-kun</span>`;
      }

      const diag = p.diagnosis || p.primary_diagnosis || '';
      const diagBadge = diag ? `<span class="status-pill" style="background: rgba(16, 185, 129, 0.12); color: var(--emerald); border: 1px solid rgba(16, 185, 129, 0.3);"><i class="fas fa-tag"></i> ${diag.length > 30 ? diag.substring(0, 30) + '...' : diag}</span>` : '';

      metaEl.innerHTML = `
        <span><strong style="color: var(--doctor-cyan-light); font-family: var(--font-mono); font-size: 0.95rem;">${p.patient_code}</strong></span> • 
        <span><i class="fas fa-user"></i> ${age} (${gender})</span> • 
        <span><i class="fas fa-phone-alt"></i> ${p.phone || '+998 90 000-00-00'}</span> • 
        <span><i class="fas fa-bed"></i> ${bed} ${dayCounterStr}</span> • 
        <span class="status-pill status-active">${program}</span>
        ${diagBadge ? ` • ${diagBadge}` : ''}
      `;
    }

    // Allergy Alert Banner in Workstation
    const allergyBanner = document.getElementById('ws-allergy-banner');
    if (allergyBanner) {
      const hasAllergy = p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q' && p.medical_allergies.trim() !== '';
      if (hasAllergy) {
        allergyBanner.style.display = 'flex';
        allergyBanner.innerHTML = `
          <i class="fas fa-exclamation-triangle"></i>
          <div>
            <strong>DORI ALLERGIYASI OGOHLANTIRISHI:</strong> Bemor <strong>${p.medical_allergies}</strong> ga yuqori sezuvchanlikka ega. Ushbu preparatlar va ularning analoglarini tayinlash qat'iyan taqiqlanadi!
          </div>
        `;
      } else {
        allergyBanner.style.display = 'none';
      }
    }

    renderAnamnesisTab();
    renderPrescriptionsTab();
    renderDailyNotesTab();
    renderEpicrisisTab();
  }

  // --- TAB 1: ANAMNESIS & EXAMINATION ---
  function renderAnamnesisTab() {
    const p = state.selectedPatient;
    if (!p) return;

    const anamnesis = state.anamnesisMap[p.id] || {
      complaints: p.notes || '',
      anamnesis_morbi: '',
      anamnesis_vitae: '',
      allergic_status: p.medical_allergies || 'Yo\'q',
      somatic_status: '',
      psychiatric_status: '',
      diagnosis_primary: p.program_type ? `${p.program_type.toUpperCase()} davolash kursi` : '',
      diagnosis_secondary: '',
      icd10_code: 'F10.2'
    };

    document.getElementById('anam-complaints').value = anamnesis.complaints || '';
    document.getElementById('anam-morbi').value = anamnesis.anamnesis_morbi || '';
    document.getElementById('anam-vitae').value = anamnesis.anamnesis_vitae || '';
    document.getElementById('anam-allergy').value = anamnesis.allergic_status || p.medical_allergies || 'Yo\'q';
    document.getElementById('anam-somatic').value = anamnesis.somatic_status || '';
    document.getElementById('anam-psychiatric').value = anamnesis.psychiatric_status || '';
    document.getElementById('anam-diagnosis-primary').value = anamnesis.diagnosis_primary || '';
    document.getElementById('anam-diagnosis-secondary').value = anamnesis.diagnosis_secondary || '';
    document.getElementById('anam-icd10').value = anamnesis.icd10_code || 'F10.2';
  }

  async function saveAnamnesis() {
    const p = state.selectedPatient;
    if (!p) return;

    const data = {
      patient_id: p.id,
      admission_id: p.active_admission ? p.active_admission.admission_id : null,
      doctor_id: (state.authenticatedDoctor && state.authenticatedDoctor.staff_id) || state.activeDoctorId,
      doctor_name: (state.authenticatedDoctor && state.authenticatedDoctor.name) || '',
      complaints: document.getElementById('anam-complaints').value,
      anamnesis_morbi: document.getElementById('anam-morbi').value,
      anamnesis_vitae: document.getElementById('anam-vitae').value,
      allergic_status: document.getElementById('anam-allergy').value,
      somatic_status: document.getElementById('anam-somatic').value,
      psychiatric_status: document.getElementById('anam-psychiatric').value,
      diagnosis_primary: document.getElementById('anam-diagnosis-primary').value,
      diagnosis_secondary: document.getElementById('anam-diagnosis-secondary').value,
      icd10_code: document.getElementById('anam-icd10').value
    };

    state.anamnesisMap[p.id] = data;
    localStorage.setItem(STORAGE_KEYS.ANAMNESIS, JSON.stringify(state.anamnesisMap));

    // Update patient allergy if edited
    p.medical_allergies = data.allergic_status;

    // Send to backend API
    try {
      await fetch('/api/doctor/anamnesis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
    } catch (e) {
      console.log('Saved to offline storage');
    }

    showToast(`✅ <strong>${p.full_name}</strong> kasallik tarixi & anamnezi muvaffaqiyatli saqlandi!`);
    renderPatientList();
    renderWorkstation();
  }

  // Smart Clinical Templates for Anamnesis
  function applyAnamnesisTemplate(key) {
    const templates = {
      complaints_alcohol: "Bosh og'rig'i, qo'llarda tremor, kuchli xumor, ko'ngil aynishi, umumiy holsizlik, yurak tez urishi va vegetativ buzilishlar.",
      complaints_abstinence: "Uyqusizlik, ichki bezovtalik, qaltiroq, disforiya, affektiv labillik, ishtahasizlik va terlash kuchayishi.",
      complaints_anxiety: "Tushkun kayfiyat, doimiy ichki xavotir, qo'rquv hissi, diqqat tarqoqligi, tungi uyquning to'liq buzilishi.",
      complaints_narcotic: "Suyak-mushaklarda qaqshash og'riqlari, bezovtalik, ko'z yoshlanishi, aksirish, qorindagi og'riqlar, disforik holat.",
      morbi_zapoy_5d: "Spirtli ichimliklarni uzluksiz iste'mol qilish davomiyligi 5 kun. Oxirgi doza 12 soat oldin. O'z vaqtida mustaqil to'xtata olmagan.",
      morbi_chronic_8y: "Spirtli ichimlik iste'mol qilish staji 8 yil, tolerantlik yuqori. O'tgan yili statsionar reabilitatsiya o'tagan.",
      morbi_first_intake: "Birinchi marta klinikaga murojaat qilishi. Toksik modda qabulidan so'ng ahvoli og'irlashgan.",
      morbi_relapse: "6 oylik remissiyadan so'ng stress fonida spirtli ichimlik qabul qilish qaytalangan (relaps).",
      vitae_standard: "O'tkazilgan yuqumli kasalliklar (OIV, Gepatit B/C) va o'tkir travmalar inkor qilinadi. Surunkali somatik kasalliklar yo'q.",
      allergy_none: "Yo'q",
      allergy_novocaine: "Novokain (terida toshmalar, qichishish)",
      allergy_penicillin: "Penitsillin guruhi antibiotiklari (Kvinke shishi xavfi)",
      somatic_moderate: "Teri qoplamalari giperemiyalangan, quruq. Til oq karash bilan qoplangan. Qo'llarda distal tremor. AQB 140/90, puls 92 ur/daq. Qorin yumshoq, og'riqsiz.",
      somatic_stable: "Teri va ko'rinadigan shilliq qavatlar tabiiy rangda. O'pka va yurak auskultatsiyasida patologik shovqinlar yo'q. AQB 120/80 mm Hg, puls 74 ur/daq, ritmik.",
      psych_anxious: "Ongi ravshan, o'z shaxsiga, makon va zamonga oriyentatsiyasi to'liq. Kayfiyati tushkun, affektiv fon labil, xavotirli. O'z holatiga tanqidiy munosabat sust.",
      psych_sedated: "Bemor sokin, tinchlangan, muloqotga kirishadi. Ko'z qarashi barqaror. Xavotir belgilari kamaygan, adekvat."
    };

    const text = templates[key];
    if (!text) return;

    if (key.startsWith('complaints_')) {
      const el = document.getElementById('anam-complaints');
      if (el) el.value = el.value ? el.value + ' ' + text : text;
    } else if (key.startsWith('morbi_')) {
      const el = document.getElementById('anam-morbi');
      if (el) el.value = el.value ? el.value + ' ' + text : text;
    } else if (key.startsWith('vitae_')) {
      const el = document.getElementById('anam-vitae');
      if (el) el.value = text;
    } else if (key.startsWith('allergy_')) {
      const el = document.getElementById('anam-allergy');
      if (el) el.value = text;
    } else if (key.startsWith('somatic_')) {
      const el = document.getElementById('anam-somatic');
      if (el) el.value = text;
    } else if (key.startsWith('psych_')) {
      const el = document.getElementById('anam-psychiatric');
      if (el) el.value = text;
    }

    showToast("⚡ Shablon matni kiritildi", "info");
  }

  function applyDiagnosisPreset(code, primaryText) {
    const icdEl = document.getElementById('anam-icd10');
    const diagEl = document.getElementById('anam-diagnosis-primary');
    if (icdEl) icdEl.value = code;
    if (diagEl) diagEl.value = primaryText;
    showToast(`✅ Tashxis tanlandi: ${code}`, "success");
  }

  // --- TAB 2: PRESCRIPTIONS & PHARMACOTHERAPY ---
  function renderPrescriptionsTab() {
    const p = state.selectedPatient;
    if (!p) return;

    let rxList = state.prescriptionsMap[p.id] || [];
    const tbody = document.getElementById('rx-table-body');
    if (!tbody) return;

    // Apply status filter if set
    const filter = state.currentRxFilter || 'all';
    if (filter === 'active') {
      rxList = rxList.filter(r => r.status === 'active');
    } else if (filter === 'completed') {
      rxList = rxList.filter(r => r.status === 'completed');
    } else if (filter === 'cancelled') {
      rxList = rxList.filter(r => r.status === 'cancelled');
    }

    if (rxList.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 2rem; color: var(--text-muted);">
            ${filter !== 'all' ? 'Ushbu toifadagi dorilar mavjud emas.' : 'Hozircha ushbu bemorga dori-darmonlar tayinlanmagan. Yuqoridagi formadan yangi dori yoki tayyor protokol qo\'shing.'}
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = rxList.map((rx, idx) => {
      const statusClass = rx.status === 'completed' ? 'status-completed' : (rx.status === 'cancelled' ? 'status-cancelled' : 'status-active');
      const statusLabel = rx.status === 'completed' ? 'Bajarildi' : (rx.status === 'cancelled' ? 'Bekor qilindi' : 'Faol');

      return `
        <tr>
          <td><strong style="color: var(--heading-color); font-size: 0.92rem;">${rx.medication_name}</strong><div style="font-size: 0.74rem; color: var(--text-muted);">${rx.form || ''}</div></td>
          <td><strong style="font-family: var(--font-mono); color: var(--doctor-cyan-light);">${rx.dosage}</strong></td>
          <td><span class="status-pill status-completed">${rx.route}</span></td>
          <td>${rx.frequency}<div style="font-size: 0.74rem; color: var(--text-muted);">${rx.timing || ''}</div></td>
          <td><strong>${rx.duration_days} kun</strong></td>
          <td><span class="status-pill ${statusClass}">${statusLabel}</span></td>
          <td>
            <div style="display: flex; gap: 4px;">
              ${rx.status === 'active' ? `
                <button class="btn-doc-primary" style="padding: 3px 8px; font-size: 0.72rem;" onclick="window.FMH_Doctor.toggleRxStatus('${p.id}', '${rx.id}', 'completed')" title="Muolaja bajarildi deb belgilash"><i class="fas fa-check"></i></button>
                <button class="btn-doc-outline" style="padding: 3px 8px; font-size: 0.72rem;" onclick="window.FMH_Doctor.toggleRxStatus('${p.id}', '${rx.id}', 'cancelled')" title="Bekor qilish"><i class="fas fa-ban"></i></button>
              ` : `
                <button class="btn-doc-outline" style="padding: 3px 8px; font-size: 0.72rem;" onclick="window.FMH_Doctor.toggleRxStatus('${p.id}', '${rx.id}', 'active')" title="Qayta faollashtirish"><i class="fas fa-redo"></i></button>
              `}
              <button class="btn-doc-danger" style="padding: 3px 8px; font-size: 0.72rem;" onclick="window.FMH_Doctor.deletePrescription('${p.id}', '${rx.id}')" title="O'chirish"><i class="fas fa-trash"></i></button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  function filterRxTable(status) {
    state.currentRxFilter = status;
    document.querySelectorAll('.rx-filter-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-rx-filter') === status);
    });
    renderPrescriptionsTab();
  }

  function setRxField(field, value) {
    const el = document.getElementById(`rx-${field}`);
    if (el) {
      el.value = value;
      el.focus();
    }
  }

  function findMedication(query) {
    if (!query) return null;
    const q = query.trim().toLowerCase();
    return state.pharmacology.find(m => 
      (m.name && m.name.toLowerCase() === q) ||
      (m.paper_name && m.paper_name.toLowerCase() === q) ||
      (m.trade_name_uz && m.trade_name_uz.toLowerCase() === q) ||
      (m.trade_name_ru && m.trade_name_ru.toLowerCase() === q) ||
      (m.name && m.name.toLowerCase().startsWith(q)) ||
      (m.paper_name && m.paper_name.toLowerCase().startsWith(q)) ||
      (m.trade_name_uz && m.trade_name_uz.toLowerCase().startsWith(q)) ||
      (m.trade_name_ru && m.trade_name_ru.toLowerCase().startsWith(q))
    ) || null;
  }

  function onDrugNameInput(value) {
    const match = findMedication(value);
    if (match) {
      if (match.form) document.getElementById('rx-form').value = match.form;
      if (match.default_dosage) document.getElementById('rx-dosage').value = match.default_dosage;
      if (match.default_route) document.getElementById('rx-route').value = match.default_route;
      if (match.default_frequency) document.getElementById('rx-frequency').value = match.default_frequency;
      if (match.default_timing) document.getElementById('rx-timing').value = match.default_timing;
      if (match.default_duration) document.getElementById('rx-duration').value = match.default_duration;
      if (match.instructions) document.getElementById('rx-instructions').value = match.instructions;
    }

    // Allergy check on input
    const p = state.selectedPatient;
    if (p && p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q') {
      const allergy = p.medical_allergies.toLowerCase();
      const val = value.toLowerCase();
      if ((val.includes('novo') && allergy.includes('novo')) || 
          (val.includes('peni') && allergy.includes('peni')) ||
          (val.includes('sulfa') && allergy.includes('sulfa'))) {
        showToast(`⚠️ <strong>DIQQAT:</strong> Bemor allergiyasi mavjud: "${p.medical_allergies}"!`, 'danger');
      }
    }
  }

  // --- 88 TA KLINIKA DORILARI MODAL OYNASI ---
  let activeClinicCat = 'all';
  let clinicMedsFilterQuery = '';

  function openClinicMedsModal() {
    let modal = document.getElementById('clinic-meds-modal');
    if (!modal) {
      createClinicMedsModalDOM();
      modal = document.getElementById('clinic-meds-modal');
    }
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    renderClinicMedsList();
  }

  function closeClinicMedsModal() {
    const modal = document.getElementById('clinic-meds-modal');
    if (modal) modal.style.display = 'none';
    document.body.style.overflow = '';
  }

  function createClinicMedsModalDOM() {
    const modalDiv = document.createElement('div');
    modalDiv.id = 'clinic-meds-modal';
    modalDiv.className = 'modal-backdrop open';
    modalDiv.style.cssText = 'position: fixed; inset: 0; background: rgba(15, 23, 42, 0.75); backdrop-filter: blur(4px); z-index: 99999; display: flex; align-items: center; justify-content: center; padding: 20px;';
    modalDiv.innerHTML = `
      <div style="background: var(--card-bg, #ffffff); border: 1px solid var(--border-color, #cbd5e1); border-radius: 16px; width: 100%; max-width: 960px; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35); overflow: hidden;">
        <!-- Header -->
        <div style="padding: 1rem 1.4rem; background: linear-gradient(135deg, #0b3b60, #0d9488); color: #ffffff; display: flex; align-items: center; justify-content: space-between;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-pills" style="font-size: 1.4rem; color: #38bdf8;"></i>
            <div>
              <h3 style="margin: 0; font-size: 1.1rem; font-weight: 800; font-family: var(--font-heading);">Fayz Medical House — 88 ta Klinika Dorilari Katalogi</h3>
              <span style="font-size: 0.76rem; opacity: 0.85;">Rasmiy ro'yxatdan tezkor retsept va muolaja tayinlash</span>
            </div>
          </div>
          <button onclick="window.FMH_Doctor.closeClinicMedsModal()" style="background: rgba(255,255,255,0.15); border: none; color: #fff; width: 32px; height: 32px; border-radius: 8px; cursor: pointer; display: flex; align-items: center; justify-content: center;">
            <i class="fas fa-times"></i>
          </button>
        </div>

        <!-- Toolbar & Filter -->
        <div style="padding: 0.85rem 1.4rem; border-bottom: 1px solid var(--border-color, #e2e8f0); display: flex; flex-direction: column; gap: 10px; background: var(--bg-card, #f8fafc);">
          <div style="position: relative;">
            <i class="fas fa-search" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #94a3b8;"></i>
            <input type="text" id="clinic-meds-search" placeholder="Dori nomi, INN, qog'ozdagi raqami yoki kasallik bo'yicha qidiruv (masalan: Verzepam, 18, Haloperidol, Qusish)..." 
              style="width: 100%; padding: 8px 12px 8px 36px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.88rem; outline: none;"
              oninput="window.FMH_Doctor.onClinicMedsFilter(this.value)">
          </div>

          <!-- Category Pills -->
          <div style="display: flex; gap: 6px; overflow-x: auto; padding-bottom: 4px; scrollbar-width: thin;" id="clinic-meds-cat-bar">
            <button class="clinic-cat-btn active" data-cat="all" onclick="window.FMH_Doctor.setClinicCat('all')">Hammasi (88)</button>
            <button class="clinic-cat-btn" data-cat="psychiatry_anxiolytics_hypnotics" onclick="window.FMH_Doctor.setClinicCat('psychiatry_anxiolytics_hypnotics')">Trankvilizatorlar (11)</button>
            <button class="clinic-cat-btn" data-cat="psychiatry_antipsychotics" onclick="window.FMH_Doctor.setClinicCat('psychiatry_antipsychotics')">Neyroleptiklar (15)</button>
            <button class="clinic-cat-btn" data-cat="psychiatry_antidepressants" onclick="window.FMH_Doctor.setClinicCat('psychiatry_antidepressants')">Antidepressantlar (12)</button>
            <button class="clinic-cat-btn" data-cat="narcology_detox" onclick="window.FMH_Doctor.setClinicCat('narcology_detox')">Narkologiya & Detoks (4)</button>
            <button class="clinic-cat-btn" data-cat="infusion_detox_solutions" onclick="window.FMH_Doctor.setClinicCat('infusion_detox_solutions')">Infuzion Eritmalar (5)</button>
            <button class="clinic-cat-btn" data-cat="cardiovascular_emergency" onclick="window.FMH_Doctor.setClinicCat('cardiovascular_emergency')">Kardiologiya & Kriz (18)</button>
            <button class="clinic-cat-btn" data-cat="neurology_nootropics" onclick="window.FMH_Doctor.setClinicCat('neurology_nootropics')">Nootroplar & Vitamin (7)</button>
            <button class="clinic-cat-btn" data-cat="mood_stabilizers_anticonvulsants" onclick="window.FMH_Doctor.setClinicCat('mood_stabilizers_anticonvulsants')">Normotimiklar (4)</button>
            <button class="clinic-cat-btn" data-cat="analgesics_antiinflammatory_general" onclick="window.FMH_Doctor.setClinicCat('analgesics_antiinflammatory_general')">Analgetiklar & NYAQV (7)</button>
            <button class="clinic-cat-btn" data-cat="hepatoprotectors_gi" onclick="window.FMH_Doctor.setClinicCat('hepatoprotectors_gi')">Oshqozon-Ichak (5)</button>
          </div>
        </div>

        <!-- List Body -->
        <div id="clinic-meds-list-container" style="flex: 1; overflow-y: auto; padding: 1rem 1.4rem; display: flex; flex-direction: column; gap: 8px;">
        </div>

        <!-- Footer -->
        <div style="padding: 0.75rem 1.4rem; border-top: 1px solid var(--border-color, #cbd5e1); display: flex; justify-content: space-between; align-items: center; background: var(--bg-card, #f8fafc); font-size: 0.8rem; color: var(--text-muted, #64748b);">
          <div>Ko'rsatilmoqda: <b id="clinic-meds-shown-count">88</b> ta dori</div>
          <button onclick="window.FMH_Doctor.closeClinicMedsModal()" class="btn-doc-outline" style="padding: 4px 14px; font-size: 0.8rem;">Yopish</button>
        </div>
      </div>
    `;
    document.body.appendChild(modalDiv);

    // Add minimal CSS for category buttons if not present
    if (!document.getElementById('clinic-meds-modal-style')) {
      const st = document.createElement('style');
      st.id = 'clinic-meds-modal-style';
      st.innerHTML = `
        .clinic-cat-btn {
          white-space: nowrap;
          padding: 4px 10px;
          border-radius: 20px;
          border: 1px solid #cbd5e1;
          background: #ffffff;
          color: #334155;
          font-size: 0.74rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s;
        }
        .clinic-cat-btn:hover { background: #e2e8f0; }
        .clinic-cat-btn.active {
          background: #0d9488;
          color: #ffffff;
          border-color: #0d9488;
        }
        .clinic-med-card {
          border: 1px solid #e2e8f0;
          border-radius: 10px;
          padding: 10px 14px;
          background: #ffffff;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          transition: all 0.15s;
        }
        .clinic-med-card:hover {
          border-color: #0d9488;
          box-shadow: 0 4px 12px rgba(13, 148, 136, 0.08);
        }
      `;
      document.head.appendChild(st);
    }
  }

  function setClinicCat(cat) {
    activeClinicCat = cat;
    document.querySelectorAll('#clinic-meds-cat-bar .clinic-cat-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-cat') === cat);
    });
    renderClinicMedsList();
  }

  function onClinicMedsFilter(query) {
    clinicMedsFilterQuery = query.trim().toLowerCase();
    renderClinicMedsList();
  }

  function renderClinicMedsList() {
    const container = document.getElementById('clinic-meds-list-container');
    if (!container) return;

    const clinicMeds = state.pharmacology
      .filter(m => m.fayz_house_list === true)
      .sort((a, b) => (a.fayz_house_num || 0) - (b.fayz_house_num || 0));

    const q = clinicMedsFilterQuery;
    const cat = activeClinicCat;

    const filtered = clinicMeds.filter(m => {
      if (cat !== 'all' && m.category !== cat) return false;
      if (!q) return true;
      const numMatch = String(m.fayz_house_num || '') === q;
      const nameMatch = (m.name || '').toLowerCase().includes(q) ||
                        (m.paper_name || '').toLowerCase().includes(q) ||
                        (m.trade_name_uz || '').toLowerCase().includes(q) ||
                        (m.trade_name_ru || '').toLowerCase().includes(q) ||
                        (m.inn || '').toLowerCase().includes(q) ||
                        (m.inn_uz || '').toLowerCase().includes(q) ||
                        (m.category_name_uz || '').toLowerCase().includes(q);
      return numMatch || nameMatch;
    });

    const countEl = document.getElementById('clinic-meds-shown-count');
    if (countEl) countEl.innerText = filtered.length;

    if (filtered.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 2.5rem; color: #94a3b8;">
          <i class="fas fa-search" style="font-size: 2rem; margin-bottom: 8px;"></i>
          <div>Kiritilgan so'rov bo'yicha hech qanday dori topilmadi.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map(m => {
      const isPsychotropic = m.prescription_type === 'Rx_Strict_Psychotropic';
      const badgeClass = isPsychotropic ? 'background: #fef2f2; color: #dc2626; border: 1px solid #fecaca;' :
                          (m.prescription_type === 'Rx_Standard' ? 'background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe;' : 'background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0;');
      const badgeText = isPsychotropic ? "⚠️ Qat'iy Psixotrop" : (m.prescription_type === 'Rx_Standard' ? "Rx (Retseptli)" : "OTC (Retseptsiz)");

      return `
        <div class="clinic-med-card">
          <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
            <div style="width: 38px; height: 38px; border-radius: 8px; background: #f1f5f9; display: flex; align-items: center; justify-content: center; font-weight: 800; color: #0b3b60; font-size: 0.85rem; border: 1px solid #cbd5e1; flex-shrink: 0;">
              №${m.fayz_house_num}
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <strong style="font-size: 0.95rem; color: #0f172a;">${m.name}</strong>
                <span style="font-size: 0.7rem; padding: 2px 6px; border-radius: 4px; font-weight: 700; ${badgeClass}">
                  ${badgeText}
                </span>
              </div>
              <div style="font-size: 0.76rem; color: #64748b; margin-top: 2px;">
                <span style="color: #0284c7; font-weight: 600;">Qog'ozdagi yozilishi:</span> ${m.paper_name} &nbsp;•&nbsp; 
                <span style="color: #64748b;">МНН: ${m.inn || m.trade_name_uz}</span> &nbsp;•&nbsp;
                <span style="color: #0d9488; font-weight: 600;">${m.form}</span>
              </div>
              <div style="font-size: 0.74rem; color: #475569; margin-top: 3px; display: flex; gap: 12px; flex-wrap: wrap;">
                <span><i class="fas fa-syringe" style="color: #94a3b8; font-size: 0.7rem;"></i> <b>Standart:</b> ${m.default_dosage} (${m.default_route})</span>
                <span><i class="fas fa-clock" style="color: #94a3b8; font-size: 0.7rem;"></i> ${m.default_frequency} • ${m.default_timing}</span>
              </div>
            </div>
          </div>

          <div style="display: flex; gap: 6px; flex-shrink: 0;">
            <button onclick="window.FMH_Doctor.fillFormWithMed(${m.fayz_house_num})" title="Formaga yuklash" 
              style="padding: 6px 10px; border-radius: 6px; border: 1px solid #cbd5e1; background: #ffffff; color: #334155; font-size: 0.76rem; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 5px;">
              <i class="fas fa-edit"></i> Formaga
            </button>
            <button onclick="window.FMH_Doctor.prescribeClinicMed(${m.fayz_house_num})" title="To'g'ridan-to'g'ri bemorga tayinlash"
              style="padding: 6px 12px; border-radius: 6px; border: none; background: #0d9488; color: #ffffff; font-size: 0.76rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 5px;">
              <i class="fas fa-plus"></i> Tayinlash
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  function fillFormWithMed(medNum) {
    const med = state.pharmacology.find(m => m.fayz_house_num === medNum || m.id === `FMH-${String(medNum).padStart(3, '0')}`);
    if (!med) return;
    const drugInput = document.getElementById('rx-drug-name');
    if (drugInput) drugInput.value = med.name;
    if (med.form) document.getElementById('rx-form').value = med.form;
    if (med.default_dosage) document.getElementById('rx-dosage').value = med.default_dosage;
    if (med.default_route) document.getElementById('rx-route').value = med.default_route;
    if (med.default_frequency) document.getElementById('rx-frequency').value = med.default_frequency;
    if (med.default_timing) document.getElementById('rx-timing').value = med.default_timing;
    if (med.default_duration) document.getElementById('rx-duration').value = med.default_duration;
    if (med.instructions) document.getElementById('rx-instructions').value = med.instructions;
    closeClinicMedsModal();
    showToast(`✅ "${med.name}" tayinlov formasiga yuklandi!`, 'success');
    if (drugInput) drugInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function prescribeClinicMed(medNum) {
    const p = state.selectedPatient;
    if (!p) {
      showToast('Iltimos, avval bemorni tanlang!', 'warning');
      return;
    }
    const med = state.pharmacology.find(m => m.fayz_house_num === medNum || m.id === `FMH-${String(medNum).padStart(3, '0')}`);
    if (!med) return;

    // Allergy check
    if (p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q') {
      const allergy = p.medical_allergies.toLowerCase();
      const dName = med.name.toLowerCase();
      if ((dName.includes('novo') && allergy.includes('novo')) ||
          (dName.includes('peni') && allergy.includes('peni')) ||
          (dName.includes('sulfa') && allergy.includes('sulfa'))) {
        const confirmPrescribe = confirm(`⚠️ OGOHLANTIRISH!\nBemor ushbu doriga allergiyaga ega: "${p.medical_allergies}".\n\nBaribir tayinlashni tasdiqlaysizmi?`);
        if (!confirmPrescribe) return;
      }
    }

    const rxData = {
      id: 'RX-' + Math.floor(Math.random() * 90000 + 10000),
      medication_name: med.name,
      form: med.form || med.dosage_form || 'Tabletkalar',
      dosage: med.default_dosage || med.strength || 'Standart doza',
      route: med.default_route || 'Ichishga (Per os)',
      frequency: med.default_frequency || 'Kuniga 2 mahal',
      duration_days: med.default_duration || 5,
      timing: med.default_timing || 'Ertalab & Kechqurun',
      instructions: med.instructions || '',
      status: 'active',
      doctor_name: state.doctors.find(d => d.id === state.activeDoctorId)?.name || 'Dr. Shifokor'
    };

    addPrescription(rxData);
    closeClinicMedsModal();
    showToast(`💊 "${med.name}" muvaffaqiyatli tayinlandi!`, 'success');
  }

  async function addPrescription(customRx = null) {
    const p = state.selectedPatient;
    if (!p) return;

    let rxData;
    if (customRx) {
      rxData = customRx;
    } else {
      const drugName = document.getElementById('rx-drug-name').value.trim();
      if (!drugName) {
        showToast('Iltimos, dori nomini kiriting!', 'warning');
        return;
      }

      // Check Allergy Safety
      if (p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q') {
        const allergy = p.medical_allergies.toLowerCase();
        const dName = drugName.toLowerCase();
        if ((dName.includes('novo') && allergy.includes('novo')) ||
            (dName.includes('peni') && allergy.includes('peni')) ||
            (dName.includes('sulfa') && allergy.includes('sulfa'))) {
          const confirmPrescribe = confirm(`⚠️ OGOHLANTIRISH!\nBemor ushbu doriga allergiyaga ega: "${p.medical_allergies}".\n\nBaribir tayinlashni tasdiqlaysizmi?`);
          if (!confirmPrescribe) return;
        }
      }

      rxData = {
        id: 'RX-' + Math.floor(Math.random() * 90000 + 10000),
        medication_name: drugName,
        form: document.getElementById('rx-form').value,
        dosage: document.getElementById('rx-dosage').value,
        route: document.getElementById('rx-route').value,
        frequency: document.getElementById('rx-frequency').value,
        duration_days: parseInt(document.getElementById('rx-duration').value) || 5,
        timing: document.getElementById('rx-timing').value,
        instructions: document.getElementById('rx-instructions').value,
        status: 'active',
        doctor_name: (state.authenticatedDoctor && state.authenticatedDoctor.name) || state.doctors.find(d => d.id === state.activeDoctorId)?.name || 'Dr. Shifokor'
      };
    }

    if (!state.prescriptionsMap[p.id]) state.prescriptionsMap[p.id] = [];
    state.prescriptionsMap[p.id].unshift(rxData);
    localStorage.setItem(STORAGE_KEYS.PRESCRIPTIONS, JSON.stringify(state.prescriptionsMap));

    // Send to backend
    try {
      await fetch('/api/doctor/prescriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: rxData.id,
          patient_id: p.id,
          admission_id: p.active_admission ? p.active_admission.admission_id : null,
          doctor_id: (state.authenticatedDoctor && state.authenticatedDoctor.staff_id) || state.activeDoctorId,
          doctor_name: (state.authenticatedDoctor && state.authenticatedDoctor.name) || rxData.doctor_name,
          ...rxData
        })
      });
    } catch (e) {}

    // Reset Form
    if (!customRx) {
      document.getElementById('rx-drug-name').value = '';
      document.getElementById('rx-dosage').value = '400 ml';
      document.getElementById('rx-instructions').value = '';
    }

    showToast(`💊 <strong>${rxData.medication_name}</strong> retsept varaqasiga muvaffaqiyatli qo'shildi!`);
    renderPrescriptionsTab();
    updateTabBadges();
    updateKPIs();
  }

  function applyPresetProtocol(protocolType) {
    const p = state.selectedPatient;
    if (!p) return;

    let items = [];
    if (protocolType === 'detox') {
      items = [
        { medication_name: 'Reamberin 1.5% 400ml', form: 'Infuzion flakon', dosage: '400 ml', route: 'V/I tomchilab (kapelnitsa)', frequency: 'Kuniga 1 mahal', duration_days: 5, timing: 'Ertalab 09:30', instructions: 'Sekin tomchilatib yuborilsin' },
        { medication_name: 'Gepa-Merts (L-ornitin-L-aspartat)', form: 'Ampula 10ml', dosage: '10 ml', route: 'V/I tomchilab (kapelnitsa)', frequency: 'Kuniga 1 mahal', duration_days: 5, timing: 'Tushlik 13:30', instructions: '200ml fiziologik eritmada eritib' },
        { medication_name: 'Meksidol (Etilmetilgidroksipiridin)', form: 'Ampula 5% 2ml', dosage: '4 ml', route: 'V/I oqimli', frequency: 'Kuniga 2 mahal', duration_days: 7, timing: 'Ertalab & Kechqurun', instructions: 'Sekin 3-5 daqiqa davomida' },
        { medication_name: 'Tiamin xlorid (Vitamin B1)', form: 'Ampula 5% 1ml', dosage: '2 ml', route: 'V/M inyeksiya', frequency: 'Kuniga 1 mahal', duration_days: 10, timing: 'Ertalab 10:00', instructions: 'Mushak ichiga' }
      ];
    } else if (protocolType === 'alcohol_abstinence') {
      items = [
        { medication_name: 'Magniy sulfat 25% 10ml', form: 'Ampula', dosage: '10 ml', route: 'V/I tomchilab (kapelnitsa)', frequency: 'Kuniga 1 mahal', duration_days: 5, timing: 'Ertalab 10:00', instructions: '200ml Glukoza 5% bilan' },
        { medication_name: 'Piridoksin (Vitamin B6)', form: 'Ampula 5% 1ml', dosage: '2 ml', route: 'V/M inyeksiya', frequency: 'Kuniga 1 mahal', duration_days: 7, timing: 'Ertalab 11:00', instructions: 'Mushak ichiga' },
        { medication_name: 'Fenazepam / Gidazepam', form: 'Tabletkalar', dosage: '0.05 g', route: 'Ichishga (Per os)', frequency: 'Kuniga 1 mahal', duration_days: 5, timing: 'Uyqudan oldin 21:30', instructions: 'Sedatsiya va uyquni barqarorlashtirish' }
      ];
    } else if (protocolType === 'hepato_neuro') {
      items = [
        { medication_name: 'Glutation (Tad 600)', form: 'Flakon 600mg', dosage: '600 mg', route: 'V/I tomchilab (kapelnitsa)', frequency: 'Kuniga 1 mahal', duration_days: 7, timing: 'Ertalab 09:30', instructions: 'VIP antioksidant' },
        { medication_name: 'Serebrolizin (Cerebrolysin)', form: 'Ampula 5ml', dosage: '5 ml', route: 'V/I oqimli', frequency: 'Kuniga 1 mahal', duration_days: 10, timing: 'Ertalab 10:30', instructions: 'Miyaning neyrometabolik tiklanishi' }
      ];
    } else if (protocolType === 'psychiatry') {
      items = [
        { medication_name: 'Grandaksin (Tofisopam)', form: 'Tabletkalar', dosage: '50 mg', route: 'Ichishga (Per os)', frequency: 'Kuniga 2 mahal', duration_days: 14, timing: 'Ertalab va Tushlik', instructions: 'Kunduzgi trankvilizator' },
        { medication_name: 'Sertralin (Zoloft)', form: 'Tabletkalar', dosage: '50 mg', route: 'Ichishga (Per os)', frequency: 'Kuniga 1 mahal', duration_days: 30, timing: 'Ertalab nonushtadan so\'ng', instructions: 'Antidepressant terapiya' }
      ];
    }

    items.forEach(item => {
      addPrescription({
        id: 'RX-' + Math.floor(Math.random() * 90000 + 10000),
        status: 'active',
        doctor_name: state.doctors.find(d => d.id === state.activeDoctorId)?.name || 'Dr. Shifokor',
        ...item
      });
    });

    showToast(`⚡ Protokol biriktirildi: <strong>${items.length} ta dori</strong> tayinlandi!`);
  }

  async function toggleRxStatus(patientId, rxId, newStatus) {
    const list = state.prescriptionsMap[patientId];
    if (!list) return;
    const item = list.find(rx => rx.id === rxId);
    if (item) {
      const oldStatus = item.status;
      item.status = newStatus; // optimistic update
      try {
        const res = await fetch(`/api/doctor/prescriptions/${rxId}/status`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newStatus })
        });
        if (!res.ok) throw new Error('API failed');

        localStorage.setItem(STORAGE_KEYS.PRESCRIPTIONS, JSON.stringify(state.prescriptionsMap));
        renderPrescriptionsTab();
        showToast(`Dori holati yangilandi: ${newStatus.toUpperCase()}`);
      } catch (err) {
        // revert
        item.status = oldStatus;
        showToast("Xatolik: Holatni yangilab bo'lmadi", "error");
      }
    }
  }

  function deletePrescription(patientId, rxId) {
    const list = state.prescriptionsMap[patientId];
    if (!list) return;
    const item = list.find(rx => rx.id === rxId);
    const medName = item ? item.medication_name : 'ushbu dorini';

    const confirmFn = window.FMH_ConfirmDialog || function({ onConfirm }) { onConfirm(); };

    confirmFn({
      title: "Retseptni O'chirish",
      message: `<strong>${medName}</strong> tayinlovini retsept varaqasidan o'chirmoqchimisiz?`,
      confirmText: "O'chirish (Enter ↵)",
      cancelText: "Bekor Qilish",
      type: "danger",
      onConfirm: async () => {
        try {
          const res = await fetch(`/api/doctor/prescriptions/${rxId}`, { method: 'DELETE' });
          if (!res.ok) throw new Error('API failed');

          state.prescriptionsMap[patientId] = list.filter(rx => rx.id !== rxId);
          localStorage.setItem(STORAGE_KEYS.PRESCRIPTIONS, JSON.stringify(state.prescriptionsMap));
          renderPrescriptionsTab();
          updateTabBadges();
          showToast("🗑️ Dori retseptdan o'chirildi");
          updateKPIs();
        } catch (err) {
          showToast("Xatolik: Retseptni o'chirib bo'lmadi", "error");
        }
      }
    });
  }

  // --- TAB 3: DAILY PROGRESS NOTES (DNEVNIK OBXODA) ---
  function renderDailyNotesTab() {
    const p = state.selectedPatient;
    if (!p) return;

    const notes = state.dailyNotesMap[p.id] || [];
    const container = document.getElementById('daily-notes-container');
    if (!container) return;

    if (notes.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
          Hozircha kunlik ko'rik qaydlari mavjud emas. Quyidagi formadan yangi ko'rik natijasini yozing.
        </div>
      `;
      return;
    }

    container.innerHTML = notes.map(n => {
      const condBadge = n.condition === 'satisfactory' ? '<span class="status-pill status-active">Qoniqarli</span>' : (n.condition === 'severe' ? '<span class="status-pill status-cancelled">Og\'ir</span>' : '<span class="status-pill status-completed">O\'rta og\'ir</span>');
      return `
        <div class="diary-entry-card">
          <div class="diary-top-row">
            <div class="diary-date"><i class="fas fa-calendar-check"></i> ${n.date} • ${n.doctor_name || 'Dr. Shifokor'}</div>
            ${condBadge}
          </div>
          <div class="diary-vitals-box">
            <span><strong>Qon bosimi:</strong> ${n.bp || '120/80'} mm Hg</span>
            <span><strong>Puls:</strong> ${n.pulse || 72} ur/min</span>
            <span><strong>Harorat:</strong> ${n.temp || 36.6} °C</span>
            <span><strong>SpO2:</strong> ${n.spo2 || 99}%</span>
          </div>
          <div style="font-size: 0.88rem; color: var(--text-primary); margin-bottom: 6px; line-height: 1.5;">
            <strong>Dinamika va holat:</strong> ${n.dynamics}
          </div>
          ${n.treatment ? `
            <div style="font-size: 0.82rem; color: var(--doctor-cyan-light); background: rgba(6, 182, 212, 0.08); padding: 6px 10px; border-radius: 6px;">
              <strong>Korreksiya:</strong> ${n.treatment}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');
  }

  async function addDailyNote() {
    const p = state.selectedPatient;
    if (!p) return;

    const dynamics = document.getElementById('note-dynamics').value.trim();
    if (!dynamics) {
      showToast('Iltimos, bemor holati dinamikasini yozing!', 'warning');
      return;
    }

    const todayStr = new Date().toISOString().split('T')[0];
    const newNote = {
      id: Date.now(),
      date: todayStr,
      condition: document.getElementById('note-condition').value,
      bp: document.getElementById('note-bp').value || '120/80',
      pulse: parseInt(document.getElementById('note-pulse').value) || 72,
      temp: parseFloat(document.getElementById('note-temp').value) || 36.6,
      spo2: parseInt(document.getElementById('note-spo2').value) || 98,
      dynamics: dynamics,
      treatment: document.getElementById('note-treatment').value,
      doctor_name: state.doctors.find(d => d.id === state.activeDoctorId)?.name || 'Dr. Shifokor'
    };

    try {
      const res = await fetch('/api/doctor/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patient_id: p.id,
          doctor_id: state.authenticatedDoctor?.staff_id,
          condition: newNote.condition,
          bp: newNote.bp,
          pulse: newNote.pulse,
          temp: newNote.temp,
          spo2: newNote.spo2,
          dynamics: newNote.dynamics,
          treatment_changes: newNote.treatment
        })
      });
      if (!res.ok) throw new Error('API failed');
      
      if (!state.dailyNotesMap[p.id]) state.dailyNotesMap[p.id] = [];
      state.dailyNotesMap[p.id].unshift(newNote);
      localStorage.setItem(STORAGE_KEYS.DAILY_NOTES, JSON.stringify(state.dailyNotesMap));

      // Reset Form
      document.getElementById('note-dynamics').value = '';
      document.getElementById('note-treatment').value = '';

      showToast(`📝 <strong>${todayStr}</strong> kungi ko'rik qaydi muvaffaqiyatli kiritildi!`);
      renderDailyNotesTab();
      updateTabBadges();
      updateVitalsDashboard();
    } catch (err) {
      showToast("Xatolik: Qaydni saqlab bo'lmadi", "error");
    }
  }

  function setNormalVitals() {
    const bpEl = document.getElementById('note-bp');
    const pulseEl = document.getElementById('note-pulse');
    const tempEl = document.getElementById('note-temp');
    const spo2El = document.getElementById('note-spo2');
    const condEl = document.getElementById('note-condition');

    if (bpEl) bpEl.value = '120/80';
    if (pulseEl) pulseEl.value = 74;
    if (tempEl) tempEl.value = 36.6;
    if (spo2El) spo2El.value = 99;
    if (condEl) condEl.value = 'satisfactory';

    showToast("⚡ Me'yoriy klinik ko'rsatkichlar o'rnatildi (120/80, 74, 36.6°C, 99%)", "info");
  }

  function appendDynamicsPhrase(phrase) {
    const el = document.getElementById('note-dynamics');
    if (!el) return;
    el.value = el.value ? el.value.trim() + ' ' + phrase : phrase;
    el.focus();
  }

  function setTreatmentPhrase(phrase) {
    const el = document.getElementById('note-treatment');
    if (!el) return;
    el.value = phrase;
    el.focus();
  }

  // --- TAB 4: DISCHARGE EPICRISIS & RECOMMENDATIONS ---
  function renderEpicrisisTab() {
    const p = state.selectedPatient;
    if (!p) return;

    const anam = state.anamnesisMap[p.id] || {};
    const rxList = state.prescriptionsMap[p.id] || [];

    const diag = anam.diagnosis_primary || (p.program_type ? `${p.program_type.toUpperCase()} davolash kursi` : '—');
    const rxSummary = rxList.map(r => `• ${r.medication_name} — ${r.dosage} (${r.route}, ${r.frequency})`).join('\n');

    document.getElementById('epicrisis-diag').textContent = diag;
    document.getElementById('epicrisis-patient').textContent = `${p.full_name} (${p.patient_code})`;
    document.getElementById('epicrisis-home-rx').value = rxSummary || '';
  }

  async function saveEpicrisis() {
    const p = state.selectedPatient;
    if (!p) return;

    const data = {
      patient_id: p.id,
      admission_id: p.active_admission ? p.active_admission.admission_id : null,
      doctor_id: (state.authenticatedDoctor && state.authenticatedDoctor.staff_id) || state.activeDoctorId,
      doctor_name: (state.authenticatedDoctor && state.authenticatedDoctor.name) || '',
      epicrisis_date: new Date().toISOString().split('T')[0],
      diagnosis_final: document.getElementById('epicrisis-diag')?.textContent || '',
      icd10_code: document.getElementById('anam-icd10')?.value || 'F10.2',
      treatment_summary: 'Detoksikatsiya va statsionar reabilitatsiya kursi muvaffaqiyatli o\'tildi.',
      home_prescriptions: document.getElementById('epicrisis-home-rx')?.value || '',
      psycho_recommendations: document.getElementById('epicrisis-psycho')?.value || '',
      discharge_status: 'recovered'
    };

    if (!state.epicrisisMap) state.epicrisisMap = {};
    state.epicrisisMap[p.id] = data;

    try {
      await fetch('/api/doctor/epicrisis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
    } catch (e) {}

    showToast(`📋 <strong>${p.full_name}</strong> chiqarish epikrizi MySQL bazasiga saqlandi!`);
  }

  function autoGenerateEpicrisis() {
    const p = state.selectedPatient;
    if (!p) {
      showToast("Avval bemorni tanlang!", "warning");
      return;
    }

    const anam = state.anamnesisMap[p.id] || {};
    const rxList = state.prescriptionsMap[p.id] || [];
    
    // Length of stay calculation
    let stayDays = 7;
    if (p.active_admission && p.active_admission.admission_date) {
      const adDate = new Date(p.active_admission.admission_date);
      const today = new Date();
      const diffDays = Math.max(1, Math.floor((today - adDate) / (1000 * 60 * 60 * 24)) + 1);
      stayDays = diffDays;
    }

    const medNames = rxList.slice(0, 5).map(r => r.medication_name).join(', ') || 'Reosorbilakt, Sibazon, Meksidol, Neyromultivit';

    const homeRxText = `1. Meksidol 125 mg tabletkasi — 1 tabletkadan kuniga 2 mahal (ertalab va tushlikda ovqatdan so'ng), 1 oy davomida.\n2. Neyromultivit (yoki B-kompleks) — 1 tabletkadan kuniga 1 mahal, 20 kun.\n3. Gepabene (yoki Essensiale Forte) — 1 kapsuladan kuniga 3 mahal, 1 oy.\n4. Magne B6 — 1 tabletkadan kechqurun, 15 kun.`;

    const psychoText = `1. Spirtli ichimliklar va har qanday psixoaktiv moddalarni qat'iyan inkor qilish (mutlaq hushyorlik rejimi).\n2. Yashash joyi bo'yicha narkolog va psixoterapevt ambulator kuzatuvida bo'lish.\n3. Psixologik reabilitatsiya va oilaviy psixoterapiya mashg'ulotlariga haftada 1 marta qatnashish.\n4. Mehnat va dam olish gigiyenasiga rioya qilish, jismoniy zo'riqish va og'ir stresslardan saqlanish.\n5. Somatik yoki ruhiy holatda salbiy o'zgarishlar sezilsa, zudlik bilan klinikaga qayta murojaat qilish.`;

    const homeRxInput = document.getElementById('epicrisis-home-rx');
    const psychoInput = document.getElementById('epicrisis-psycho');
    if (homeRxInput) homeRxInput.value = homeRxText;
    if (psychoInput) psychoInput.value = psychoText;

    showToast("⚡ Avtomatik epikriz va tavsiyalar shakllantirildi!", "success");
  }

  function appendHomeRx(text) {
    const el = document.getElementById('epicrisis-home-rx');
    if (!el) return;
    el.value = text;
    el.focus();
    showToast("Uyga davolanish paketi o'rnatildi", "info");
  }

  function setPsychoRec(text) {
    const el = document.getElementById('epicrisis-psycho');
    if (!el) return;
    el.value = text;
    el.focus();
    showToast("Reabilitatsiya tavsiyalari kiritildi", "info");
  }

  // =========================================================================
  // OFFICIAL PRINT & PDF EXPORT ENGINE WITH CLINIC CREDENTIALS
  // =========================================================================
  function openOfficialDocModal(docType = 'prescriptions') {
    const modal = document.getElementById('official-doc-modal');
    if (!modal) return;
    const select = document.getElementById('doc-type-select');
    if (select) select.value = docType;
    modal.style.display = 'flex';
    renderOfficialDocumentPreview();
  }

  function closeOfficialDocModal() {
    const modal = document.getElementById('official-doc-modal');
    if (modal) modal.style.display = 'none';
  }

    function printOfficialDocument(docType = 'prescriptions') {
    const p = state.selectedPatient;
    if (!p) {
      showToast('Iltimos, avval bemorni tanlang!', 'warning');
      return;
    }
    const activeDoc = state.authenticatedDoctor || state.doctors.find(d => d.id === state.activeDoctorId) || state.doctors[0];
    const rxList = state.prescriptionsMap[p.id] || [];
    const epicrisis = (state.epicrisisMap && state.epicrisisMap[p.id]) || {};

    if (window.FMH_Print) {
      if (docType === 'prescriptions') {
        window.FMH_Print.prescriptionSheet(p, rxList, activeDoc);
      } else if (docType === 'epicrisis') {
        window.FMH_Print.dischargeEpicrisis(p, epicrisis, activeDoc);
      } else {
        window.FMH_Print.dischargeEpicrisis(p, epicrisis, activeDoc);
      }
    } else {
      openOfficialDocModal(docType);
      setTimeout(() => { window.print(); }, 150);
    }
  }

  async function downloadPDF() {
    const p = state.selectedPatient;
    if (!p) {
      showToast('Iltimos, avval bemorni tanlang!', 'warning');
      return;
    }
    const docType = document.getElementById('doc-type-select')?.value || 'prescriptions';
    const filename = `FMH_${docType.toUpperCase()}_${p.patient_code || p.id}.pdf`;

    showToast('⏳ <strong>MySQL ma\'lumotlar bazasidan PDF yaratilmoqda...</strong>', 'info');

    try {
      const pdfUrl = `/api/doctor/download-pdf/${p.id}?doc_type=${docType}`;
      const res = await fetch(pdfUrl);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();

      setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
        a.remove();
      }, 1000);

      showToast('✅ <strong>SQL ma\'lumotlari asosida PDF yuklab olindi!</strong>', 'success');
    } catch (err) {
      console.warn('Blob fetch download fallback', err);
      window.open(`/api/doctor/download-pdf/${p.id}?doc_type=${docType}`, '_blank');
    }
  }

  function renderOfficialDocumentPreview() {
    const p = state.selectedPatient;
    const container = document.getElementById('printable-a4-document');
    if (!container) return;

    if (!p) {
      container.innerHTML = `<div style="text-align: center; padding: 3rem; color: #64748b;">Iltimos, avval bemorni tanlang!</div>`;
      return;
    }

    const docType = document.getElementById('doc-type-select')?.value || 'prescriptions';
    const activeDoc = state.authenticatedDoctor || state.doctors.find(d => d.id === state.activeDoctorId) || state.doctors[0];
    const anam = state.anamnesisMap[p.id] || {};
    const rxList = state.prescriptionsMap[p.id] || [];
    const dailyNotes = state.dailyNotesMap[p.id] || [];
    const epicrisis = (state.epicrisisMap && state.epicrisisMap[p.id]) || {};

    const age = p.birth_year ? (2026 - p.birth_year) : 'N/A';
    const genderStr = p.gender === 'female' ? 'Ayol' : 'Erkak';
    const roomStr = p.active_admission ? `${p.active_admission.room_number}-xona (${p.active_admission.bed_code})` : 'Ambulator';
    const todayStr = new Date().toLocaleDateString('uz-UZ', { year: 'numeric', month: 'long', day: 'numeric' });

    let titleText = "RASMIY MUOLAJA VARAQASI (LIST NAZNACHENIY)";
    let subtitleText = "Klinik dori-darmonlar va tibbiy muolajalar tayinlovi";

    if (docType === 'anamnesis') {
      titleText = "KASALLIK TARIXI VA KASALLIK ANAMNEZI (EMR)";
      subtitleText = "Statsionar / Ambulator bemorning birlamchi tibbiy ko'rik hujjati";
    } else if (docType === 'epicrisis') {
      titleText = "STATSIONARDAN CHIQARISH EPIKRIZI";
      subtitleText = "Rasmiy tibbiy xulosa, natijalar va uyda davolanish tavsiyalari";
    } else if (docType === 'full_dossier') {
      titleText = "TO'LIQ BEMOR KLINIK EMR DOSSYESI";
      subtitleText = "Yagona kompleks tibbiy hujjat (Anamnez, Retseptlar, Ko'riklar & Epikriz)";
    }

    let mainContentHtml = '';

    // SECTION 1: PRESCRIPTIONS TABLE
    const rxTableHtml = `
      <div class="a4-section-title"><i class="fas fa-pills"></i> Dori-Darmon va Muolaja Tayinlovlari (List Naznacheniy)</div>
      <table class="a4-table">
        <thead>
          <tr>
            <th style="width: 30px;">№</th>
            <th>Dori vositasi & Shakli</th>
            <th>Doza</th>
            <th>Yuborish Yo'li</th>
            <th>Qabul vaqti / Davriyligi</th>
            <th>Davomiyligi</th>
            <th>Holati</th>
          </tr>
        </thead>
        <tbody>
          ${rxList.length > 0 ? rxList.map((r, i) => `
            <tr>
              <td>${i + 1}</td>
              <td><strong>${r.medication_name}</strong><br><small style="color: #64748b;">${r.form || ''}</small></td>
              <td><strong>${r.dosage}</strong></td>
              <td>${r.route}</td>
              <td>${r.frequency}<br><small style="color: #64748b;">${r.timing || ''}</small></td>
              <td>${r.duration_days} kun</td>
              <td><span style="font-weight: 700; color: ${r.status === 'completed' ? '#10b981' : (r.status === 'cancelled' ? '#f43f5e' : '#0284c7')};">${r.status === 'completed' ? 'Bajarildi' : (r.status === 'cancelled' ? 'Bekor qilindi' : 'Bajarilmoqda')}</span></td>
            </tr>
          `).join('') : '<tr><td colspan="7" style="text-align: center; color: #94a3b8;">Tayinlangan dori-darmonlar yo\'q.</td></tr>'}
        </tbody>
      </table>
    `;

    // SECTION 2: ANAMNESIS HTML
    const anamnesisHtml = `
      <div class="a4-section-title"><i class="fas fa-notes-medical"></i> Bemor Shikoyatlari & Anamnezi</div>
      <div style="font-size: 12.5px; display: grid; gap: 8px; margin-bottom: 16px;">
        <div><strong>Bemor shikoyatlari:</strong> ${document.getElementById('anam-complaints')?.value || anam.complaints || 'Patsiyent intoksikatsiya, uyqusizlik, vegetativ o\'zgarishlar va umumiy hollardan shikoyat qiladi.'}</div>
        <div><strong>Anamnesis Morbi (Kasallik rivojlanishi):</strong> ${document.getElementById('anam-morbi')?.value || anam.anamnesis_morbi || 'Surunkali toksik/alkogolli intoksikatsiya holati. Zapoy staji 5 kun.'}</div>
        <div><strong>Anamnesis Vitae (Hayotiy anamnez):</strong> ${document.getElementById('anam-vitae')?.value || anam.anamnesis_vitae || 'O\'tkazilgan yuqumli kasalliklar (OIV, Gepatit B/C) va travmalar inkor qilinadi.'}</div>
        <div><strong>Somatik & Nevrologik holat:</strong> ${document.getElementById('anam-somatic')?.value || anam.somatic_status || 'Teri qoplamalari rangpar, tremori bor, arterial bosim 120/80 mm Hg, puls 74 ur/min.'}</div>
        <div><strong>Psixik status:</strong> ${document.getElementById('anam-psychiatric')?.value || anam.psychiatric_status || 'Ongi saqlangan, zamon va makonda orientatsiyasi bor. Affektiv fon bezovta.'}</div>
      </div>
    `;

    // SECTION 3: DAILY NOTES HTML
    const dailyNotesHtml = `
      <div class="a4-section-title"><i class="fas fa-clipboard-list"></i> Shifokor Kundalik Ko'rigi Qaydlari (Dnevnik Obxoda)</div>
      <table class="a4-table">
        <thead>
          <tr>
            <th style="width: 90px;">Sana</th>
            <th style="width: 100px;">Gemodinamika</th>
            <th>Holat Dinamikasi va O'zgarishlar</th>
            <th>Korreksiya</th>
          </tr>
        </thead>
        <tbody>
          ${dailyNotes.length > 0 ? dailyNotes.map(n => `
            <tr>
              <td><strong>${n.date}</strong></td>
              <td>Bosim: ${n.bp || '120/80'}<br>Puls: ${n.pulse || 72}<br>Temp: ${n.temp || 36.6}°C</td>
              <td>${n.dynamics}</td>
              <td>${n.treatment || 'O\'zgarishsiz'}</td>
            </tr>
          `).join('') : '<tr><td colspan="4" style="text-align: center; color: #94a3b8;">Kundalik ko\'rik qaydlari mavjud emas.</td></tr>'}
        </tbody>
      </table>
    `;

    // SECTION 4: EPICRISIS HTML
    const epicrisisHtml = `
      <div class="a4-section-title"><i class="fas fa-file-signature"></i> Chiqarish Epikrizi & Uyga Davolanish Tavsiyalari</div>
      <div style="font-size: 12.5px; display: grid; gap: 10px; margin-bottom: 16px;">
        <div style="background: #f8fafc; padding: 10px; border-radius: 6px; border: 1px solid #e2e8f0;">
          <strong>Klinik Xulosa va Natija:</strong> ${epicrisis.treatment_summary || 'Bemor klinikada detoksikatsiya va statsionar reabilitatsiya kursini to\'liq o\'tdi. Holati barqarorlashdi.'}
        </div>
        <div>
          <strong>Uyda Davom Ettirish Uchun Tavsiya Etilgan Farmakoterapiya:</strong>
          <pre style="font-family: inherit; white-space: pre-wrap; margin-top: 4px; background: #fff; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px;">${document.getElementById('epicrisis-home-rx')?.value || epicrisis.home_prescriptions || "1. Meksidol 125mg tabletka — kuniga 2 mahal, 1 oy.\n2. Neyromultivit — kuniga 1 tabletka, 20 kun."}</pre>
        </div>
        <div>
          <strong>Psixoterapevtik va Reabilitatsiya Tavsiyalari:</strong>
          <div style="background: #fff; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; margin-top: 4px;">${document.getElementById('epicrisis-psycho')?.value || epicrisis.psycho_recommendations || "Psixoterapevt qabuliga haftada 1 marta qatnashish, 12 qadam dasturi bo'yicha mashg'ulotlar."}</div>
        </div>
      </div>
    `;

    if (docType === 'prescriptions') {
      mainContentHtml = rxTableHtml;
    } else if (docType === 'anamnesis') {
      mainContentHtml = anamnesisHtml + rxTableHtml;
    } else if (docType === 'epicrisis') {
      mainContentHtml = epicrisisHtml;
    } else if (docType === 'full_dossier') {
      mainContentHtml = anamnesisHtml + rxTableHtml + dailyNotesHtml + epicrisisHtml;
    }

    const primaryDiag = document.getElementById('anam-diagnosis-primary')?.value || anam.diagnosis_primary || 'Surunkali alkogolizm 2-bosqich. Abstinensiya sindromi.';
    const icdCode = document.getElementById('anam-icd10')?.value || anam.icd10_code || 'F10.2';

    container.innerHTML = `
      <!-- Official Clinic Header Letterhead -->
      <div class="a4-clinic-header">
        <div class="a4-brand-logo">
          <div class="a4-brand-icon">
            <i class="fas fa-hospital-alt"></i>
          </div>
          <div>
            <div class="a4-brand-name">FAYZ MEDICAL HOUSE</div>
            <div class="a4-brand-sub">XUSUSIY NARKOLOGIYA VA PSIXIATRIYA KLINIKASI</div>
          </div>
        </div>

        <div class="a4-clinic-meta">
          <div><strong>O'zR SSV Litsenziyasi:</strong> № 4082-00</div>
          <div><strong>Manzil:</strong> Toshkent sh., Yunusobod t., Bodomzor str. 42</div>
          <div><strong>Ishonch Telefoni:</strong> +998 (71) 200-03-03 / +998 (90) 372-03-03</div>
          <div><strong>Veb-sayt:</strong> www.fayzmedicalhouse.uz</div>
        </div>
      </div>

      <!-- Document Title Bar -->
      <div class="a4-doc-title-bar">
        <div class="a4-doc-title">${titleText}</div>
        <div class="a4-doc-subtitle">${subtitleText} • Sana: ${todayStr}</div>
      </div>

      <!-- Patient Identity Grid -->
      <div class="a4-patient-grid">
        <div class="a4-patient-field"><span>Bemor F.I.SH.:</span> <strong>${p.full_name}</strong></div>
        <div class="a4-patient-field"><span>Bemor Kodi/ID:</span> <strong style="color: #0284c7;">${p.patient_code}</strong></div>
        <div class="a4-patient-field"><span>Yoshi / Jinsi:</span> <strong>${age} yosh (${genderStr})</strong></div>
        <div class="a4-patient-field"><span>Joylashuvi / Xona:</span> <strong>${roomStr}</strong></div>
        <div class="a4-patient-field"><span>Asosiy Klinik Tashxis:</span> <strong>${primaryDiag}</strong></div>
        <div class="a4-patient-field"><span>XKT-10 (ICD-10) Kodi:</span> <strong>${icdCode}</strong></div>
        <div class="a4-patient-field" style="grid-column: span 2;"><span>Dori Allergiyalari Statusi:</span> <strong style="color: ${p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q' ? '#f43f5e' : '#10b981'};">${p.medical_allergies || 'Qayd etilmagan (Yo\'q)'}</strong></div>
      </div>

      <!-- Main Clinical Content Area -->
      ${mainContentHtml}

      <!-- Official Doctor Signature & Stamp Footer Block -->
      <div class="a4-footer-signature">
        <div>
          <div style="font-weight: 700; color: #0f172a; margin-bottom: 2px;">Mas'ul / Navbatchi Shifokor:</div>
          <div style="font-size: 13px; font-weight: 800; color: #0284c7;">${activeDoc.name}</div>
          <div style="font-size: 10px; color: #64748b;">${activeDoc.title || 'Klinik Narkolog & Psixiatr'}</div>
          <div style="margin-top: 25px; border-top: 1px solid #000; width: 140px; text-align: center; font-size: 9px; color: #64748b;">(Shifokor Imzosi)</div>
        </div>

        <div style="text-align: center;">
          <div class="stamp-box">
            FAYZ MEDICAL HOUSE<br>KLINIKA MUHR O'RNI<br>(OFFICIAL STAMP)
          </div>
        </div>

        <div style="text-align: right;">
          <div style="font-weight: 700; color: #0f172a;">Hujjat Verifikatsiyasi:</div>
          <div style="font-size: 10px; color: #64748b; margin-top: 4px;">Sertifikat kodi: EMR-${p.patient_code}-${Math.floor(Math.random()*8999+1000)}</div>
          <div style="font-size: 10px; color: #64748b;">Chop etilgan vaqt: ${new Date().toLocaleTimeString('uz-UZ')}</div>
          <div style="margin-top: 10px; font-size: 9px; color: #94a3b8;">Ushbu hujjat Fayz Medical House EMR MySQL 8.0 ma'lumotlar bazasi tomonidan tasdiqlangan.</div>
        </div>
      </div>
    `;
  }

  // KPI updater
  function updateKPIs() {
    const chipInpatients = document.getElementById('kpi-inpatients-count');
    const chipPrescriptions = document.getElementById('kpi-rx-count');
    const chipAllergies = document.getElementById('kpi-allergy-count');

    const inpatientsCount = state.patients.filter(p => p.status === 'active' && p.active_admission).length;
    let totalRx = 0;
    Object.values(state.prescriptionsMap).forEach(list => totalRx += list.filter(r => r.status === 'active').length);
    const allergyCount = state.patients.filter(p => p.medical_allergies && p.medical_allergies.toLowerCase() !== 'yo\'q' && p.medical_allergies.trim() !== '').length;

    if (chipInpatients) chipInpatients.textContent = inpatientsCount;
    if (chipPrescriptions) chipPrescriptions.textContent = totalRx;
    if (chipAllergies) chipAllergies.textContent = allergyCount;
  }

  // Tab switcher
  function switchTab(tabId) {
    state.activeTab = tabId;
    document.querySelectorAll('.ws-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tabId);
    });
    document.querySelectorAll('.ws-tab-pane').forEach(pane => {
      pane.classList.toggle('active', pane.id === `tab-${tabId}`);
    });
  }

  // Event Listeners setup
  function setupEventListeners() {
    const searchInput = document.getElementById('doctor-patient-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        state.searchQuery = e.target.value.trim();
        filterPatients(state.currentFilter);
      });
    }

    const drugNameInput = document.getElementById('rx-drug-name');
    if (drugNameInput) {
      drugNameInput.addEventListener('input', (e) => onDrugNameInput(e.target.value));
    }
  }

  async function deleteCurrentPatient() {
    const p = state.selectedPatient;
    if (!p) {
      showToast('Iltimos, avval bemorni tanlang!', 'warning');
      return;
    }

    if (!confirm(`Haqiqatan ham "${p.full_name}" bemorini va uning barcha tibbiy, statsionar va farmakologik qaydlarini butunlay o'chirmoqchimisiz?`)) {
      return;
    }

    try {
      await fetch('/api/patients/' + encodeURIComponent(p.id), { method: 'DELETE' });
    } catch (e) {
      console.warn('DELETE patient error:', e);
    }

    state.patients = state.patients.filter(pt => pt.id !== p.id);
    state.selectedPatient = null;
    renderPatientList();
    renderWorkstation();
    showToast(`🗑️ "${p.full_name}" bazadan butunlay o'chirildi!`, 'danger');
  }

  // =========================================================================
  // DOCTOR AUTHENTICATION & IDENTITY ENGINE
  // =========================================================================
  function checkDoctorAuth() {
    const savedDoc = localStorage.getItem(STORAGE_KEYS.ACTIVE_DOCTOR);
    if (savedDoc) {
      try {
        const parsed = JSON.parse(savedDoc);
        if (parsed && (parsed.username || parsed.staff_id)) {
          state.authenticatedDoctor = parsed;
          state.activeDoctorId = parsed.staff_id;
          hideDoctorAuthModal();
          return true;
        }
      } catch (e) {}
    }

    const activeUser = localStorage.getItem('fmh_active_user') || localStorage.getItem('fmh_user');
    if (activeUser) {
      try {
        const u = JSON.parse(activeUser);
        const match = CLINIC_DOCTORS.find(d => d.username === u.username || d.staff_id === u.staff_id);
        if (match) {
          state.authenticatedDoctor = match;
          state.activeDoctorId = match.staff_id;
          localStorage.setItem(STORAGE_KEYS.ACTIVE_DOCTOR, JSON.stringify(match));
          hideDoctorAuthModal();
          return true;
        } else if (u.role === 'superadmin' || u.role === 'admin') {
          state.authenticatedDoctor = { ...CLINIC_DOCTORS[0], is_superadmin: true };
          state.activeDoctorId = CLINIC_DOCTORS[0].staff_id;
          localStorage.setItem(STORAGE_KEYS.ACTIVE_DOCTOR, JSON.stringify(state.authenticatedDoctor));
          hideDoctorAuthModal();
          return true;
        }
      } catch (e) {}
    }

    showDoctorAuthModal();
    return false;
  }

  function showDoctorAuthModal() {
    const modal = document.getElementById('doctor-auth-modal');
    if (modal) {
      modal.style.display = 'flex';
      document.body.style.overflow = 'hidden';
    }
  }

  function hideDoctorAuthModal() {
    const modal = document.getElementById('doctor-auth-modal');
    if (modal) {
      modal.style.display = 'none';
      document.body.style.overflow = '';
    }
  }

  function selectAuthPreset(username, password) {
    const uInput = document.getElementById('auth-doctor-username');
    const pInput = document.getElementById('auth-doctor-password');
    if (uInput) uInput.value = username;
    if (pInput) {
      pInput.value = password;
      pInput.focus();
    }

    document.querySelectorAll('.auth-doc-card').forEach(card => {
      card.classList.toggle('active', card.id === `auth-preset-${username}`);
    });

    const err = document.getElementById('auth-error-msg');
    if (err) err.style.display = 'none';
  }

  async function handleAuthSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();
    const username = (document.getElementById('auth-doctor-username')?.value || '').trim();
    const password = (document.getElementById('auth-doctor-password')?.value || '').trim();
    const errEl = document.getElementById('auth-error-msg');

    if (!username || !password) {
      if (errEl) {
        errEl.innerText = 'Iltimos, login va parolni kiriting!';
        errEl.style.display = 'block';
      }
      return;
    }

    let verified = false;
    let doctorData = null;

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.ok && data.user) {
          verified = true;
          const clinicMatch = CLINIC_DOCTORS.find(d => d.username === data.user.username);
          doctorData = clinicMatch || {
            username: data.user.username,
            staff_id: data.user.staff_id || 'STF-DOC-01',
            name: data.user.full_name || 'Dr. Shifokor',
            role: data.user.role === 'chief_doctor' ? 'Bosh Shifokor / Narkolog' : 'Shifokor',
            specialty: data.user.specialty || 'Narkologiya',
            avatar: '👨‍⚕️'
          };
        }
      }
    } catch (netErr) {
      console.warn("Backend auth call failed, checking local credentials", netErr);
    }

    if (!verified) {
      const localMatch = CLINIC_DOCTORS.find(d => d.username === username && d.password === password);
      if (localMatch) {
        verified = true;
        doctorData = localMatch;
      } else if ((username === 'doctor' && password === 'doc2026') || (username === 'superadmin' && password === 'admin2026')) {
        verified = true;
        doctorData = CLINIC_DOCTORS[0];
      }
    }

    if (!verified) {
      if (errEl) {
        errEl.innerText = 'Login yoki parol noto\'g\'ri! Shifokor ma\'lumotlarini tekshiring.';
        errEl.style.display = 'block';
      }
      showToast('Noto\'g\'ri login yoki parol!', 'danger');
      return;
    }

    state.authenticatedDoctor = doctorData;
    state.activeDoctorId = doctorData.staff_id;
    localStorage.setItem(STORAGE_KEYS.ACTIVE_DOCTOR, JSON.stringify(doctorData));
    localStorage.setItem('fmh_active_user', JSON.stringify({
      username: doctorData.username,
      full_name: doctorData.name,
      role: 'doctor',
      staff_id: doctorData.staff_id
    }));

    hideDoctorAuthModal();
    updateDoctorIdentityDisplay();
    filterPatients(state.currentFilter);
    showToast(`✅ Xush kelibsiz, <strong>${doctorData.name}</strong>!`, 'success');
  }

  function logoutDoctor() {
    if (!confirm("Haqiqatan ham shifokor shaxsiy kabinetidan chiqmoqchimisiz?")) return;
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_DOCTOR);
    state.authenticatedDoctor = null;
    state.activeDoctorId = '';
    showDoctorAuthModal();
    updateDoctorIdentityDisplay();
    showToast("Shifokor hisobidan chiqildi", "info");
  }

  function updateDoctorIdentityDisplay() {
    const doc = state.authenticatedDoctor || CLINIC_DOCTORS[0];
    const nameEl = document.getElementById('active-doctor-display-name');
    const titleEl = document.getElementById('active-doctor-display-title');
    const avatarEl = document.getElementById('active-doctor-avatar');
    const modalDocEl = document.getElementById('case-modal-doctor-name');

    if (nameEl) nameEl.textContent = doc.name;
    if (titleEl) titleEl.textContent = doc.role || doc.specialty || 'Shifokor';
    if (avatarEl) avatarEl.textContent = doc.avatar || '👨‍⚕️';
    if (modalDocEl) modalDocEl.textContent = `${doc.name} (${doc.role || doc.specialty})`;
  }

  // =========================================================================
  // MULTI-STEP CONSULTATION, KASALLIK VARAQASI & RETSEPTLAR WORKFLOW
  // =========================================================================
  async function openNewConsultationModal() {
    if (!state.authenticatedDoctor) {
      showDoctorAuthModal();
      return;
    }

    const form = document.getElementById('new-case-form');
    if (form) form.reset();

    state.newCase = {
      step: 1,
      intakeType: 'outpatient',
      prescriptions: []
    };

    updateDoctorIdentityDisplay();
    toggleIntakeType('outpatient');
    switchCaseStep(1);
    renderModalPrescriptions();
    await loadBedOptionsForModal();

    const modal = document.getElementById('doctor-consultation-case-modal');
    if (modal) {
      modal.style.display = 'flex';
      document.body.style.overflow = 'hidden';
    }
  }

  function closeNewConsultationModal() {
    const modal = document.getElementById('doctor-consultation-case-modal');
    if (modal) {
      modal.style.display = 'none';
      document.body.style.overflow = '';
    }
  }

  function toggleIntakeType(type) {
    state.newCase.intakeType = type;
    const optOut = document.getElementById('opt-intake-outpatient');
    const optIn = document.getElementById('opt-intake-inpatient');
    const bedSec = document.getElementById('inpatient-room-bed-section');

    if (type === 'inpatient') {
      optIn?.classList.add('selected');
      optOut?.classList.remove('selected');
      if (bedSec) bedSec.style.display = 'block';
    } else {
      optOut?.classList.add('selected');
      optIn?.classList.remove('selected');
      if (bedSec) bedSec.style.display = 'none';
    }
  }

  async function loadBedOptionsForModal() {
    const select = document.getElementById('case-bed-select');
    if (!select) return;

    select.innerHTML = '<option value="">— Koykani tanlang —</option>';

    let beds = [];
    try {
      const res = await fetch('/api/facility/rooms');
      if (res.ok) {
        const data = await res.json();
        if (data && data.floors) {
          data.floors.forEach(fl => {
            (fl.rooms || []).forEach(rm => {
              (rm.beds || []).forEach(bd => {
                beds.push({
                  bed_id: bd.bed_id || bd.id,
                  room_number: rm.room_number || rm.name_uz,
                  bed_number: bd.bed_number || bd.label,
                  room_type: rm.room_type || bd.type || 'Standart',
                  status: bd.status || 'available',
                  patient_name: bd.patient_name || ''
                });
              });
            });
          });
        }
      }
    } catch (e) {
      console.warn("Could not load /api/facility/rooms, using fallback beds", e);
    }

    if (beds.length === 0) {
      const fallbackRooms = [
        { room: "11", type: "Standart", beds: ["1A", "1B"] },
        { room: "12", type: "Standart", beds: ["2A", "2B"] },
        { room: "21", type: "VIP", beds: ["3A", "3B"] },
        { room: "22", type: "VIP", beds: ["4A", "4B"] },
        { room: "23", type: "Standart", beds: ["5A", "5B"] },
        { room: "24", type: "Standart", beds: ["6A", "6B"] },
        { room: "25", type: "Standart", beds: ["7A", "7B"] }
      ];
      fallbackRooms.forEach(r => {
        r.beds.forEach(b => {
          beds.push({
            bed_id: `BED-${b}`,
            room_number: r.room,
            bed_number: b,
            room_type: r.type,
            status: 'available',
            patient_name: ''
          });
        });
      });
    }

    select.innerHTML = '<option value="">— Bo\'sh koykani tanlang —</option>' + beds.map(b => {
      const isOccupied = b.status === 'occupied' || (b.patient_name && b.patient_name.trim() !== '');
      const label = `${b.room_number}-xona (${b.room_type}) — Koyka ${b.bed_number} ${isOccupied ? `[Band: ${b.patient_name}]` : "[Bo'sh]"}`;
      return `<option value="${b.bed_id}" data-room="${b.room_number}" data-bed="${b.bed_number}" data-type="${b.room_type}" ${isOccupied ? 'disabled style="color: #94a3b8;"' : ''}>${label}</option>`;
    }).join('');

    select.onchange = () => {
      const opt = select.options[select.selectedIndex];
      const roomType = opt ? opt.getAttribute('data-type') : 'Standart';
      const typeInput = document.getElementById('case-room-type');
      if (typeInput) typeInput.value = roomType || 'Standart';
    };
  }

  function switchCaseStep(step) {
    if (step < 1 || step > 3) return;

    if (step > 1) {
      const name = document.getElementById('case-patient-name')?.value.trim();
      const dob = document.getElementById('case-patient-dob')?.value.trim();
      const phone = document.getElementById('case-patient-phone')?.value.trim();

      if (!name || !dob || !phone) {
        showToast("Iltimos, bemorning F.I.Sh., yoshi va telefon raqamini to'liq kiriting!", "warning");
        return;
      }

      if (state.newCase.intakeType === 'inpatient') {
        const bed = document.getElementById('case-bed-select')?.value;
        if (!bed) {
          showToast("Statsionar yotqizish uchun xona va koykani tanlang!", "warning");
          return;
        }
      }
    }

    if (step > 2) {
      const complaints = document.getElementById('case-complaints')?.value.trim();
      const diagnosis = document.getElementById('case-diagnosis')?.value.trim();

      if (!complaints || !diagnosis) {
        showToast("Iltimos, asosiy shikoyatlar va klinik tashxisni kiriting!", "warning");
        return;
      }
    }

    state.newCase.step = step;

    [1, 2, 3].forEach(n => {
      const tab = document.getElementById(`case-tab-btn-${n}`);
      const pane = document.getElementById(`case-step-${n}`);
      if (tab) tab.classList.toggle('active', n === step);
      if (pane) pane.classList.toggle('active', n === step);
    });

    const btnPrev = document.getElementById('btn-case-prev');
    const btnNext = document.getElementById('btn-case-next');
    const btnSubmit = document.getElementById('btn-case-submit');

    if (btnPrev) btnPrev.style.display = step > 1 ? 'inline-flex' : 'none';
    if (btnNext) btnNext.style.display = step < 3 ? 'inline-flex' : 'none';
    if (btnSubmit) btnSubmit.style.display = step === 3 ? 'inline-flex' : 'none';
  }

  function nextCaseStep() {
    switchCaseStep(state.newCase.step + 1);
  }

  function prevCaseStep() {
    switchCaseStep(state.newCase.step - 1);
  }

  function addModalPrescriptionRow() {
    const drugNameInput = document.getElementById('modal-rx-drug-name');
    const dosageInput = document.getElementById('modal-rx-dosage');
    const routeSelect = document.getElementById('modal-rx-route');
    const daysInput = document.getElementById('modal-rx-days');
    const notesInput = document.getElementById('modal-rx-notes');

    const drugName = (drugNameInput?.value || '').trim();
    if (!drugName) {
      showToast("Iltimos, dori vositasi nomini kiriting!", "warning");
      return;
    }

    const allergyText = (document.getElementById('case-allergies')?.value || '').toLowerCase();
    const dLower = drugName.toLowerCase();
    if (allergyText && allergyText !== 'yo\'q') {
      if ((dLower.includes('novo') && allergyText.includes('novo')) ||
          (dLower.includes('peni') && allergyText.includes('peni')) ||
          (dLower.includes('sulfa') && allergyText.includes('sulfa'))) {
        const confirmAllergy = confirm(`⚠️ DIQQAT!\nUshbu bemorda allergik xavf qayd etilgan: "${allergyText}".\n\nBaribir retseptga qo'shasizmi?`);
        if (!confirmAllergy) return;
      }
    }

    const item = {
      id: 'RX-' + Math.floor(Math.random() * 90000 + 10000),
      medication_name: drugName,
      form: routeSelect?.value.includes('tomchi') ? 'Infuzion flakon' : (routeSelect?.value.includes('per os') ? 'Tabletkalar' : 'Ampula'),
      dosage: dosageInput?.value.trim() || 'Standart',
      route: routeSelect?.value || 'v/i tomchilab',
      duration_days: parseInt(daysInput?.value) || 5,
      frequency: notesInput?.value.trim() || 'Kuniga 1 marta',
      timing: 'Muolaja jadvali bo\'yicha',
      instructions: notesInput?.value.trim() || '',
      status: 'active'
    };

    state.newCase.prescriptions.push(item);
    renderModalPrescriptions();

    if (drugNameInput) drugNameInput.value = '';
    if (dosageInput) dosageInput.value = '';
    if (notesInput) notesInput.value = '';
    showToast(`💊 "${item.medication_name}" tayinlovlar ro'yxatiga qo'shildi!`, "info");
  }

  function removeModalPrescriptionRow(idx) {
    if (idx >= 0 && idx < state.newCase.prescriptions.length) {
      const removed = state.newCase.prescriptions.splice(idx, 1);
      renderModalPrescriptions();
      showToast(`O'chirildi: ${removed[0]?.medication_name}`, "info");
    }
  }

  function renderModalPrescriptions() {
    const tbody = document.getElementById('modal-prescriptions-table-body');
    if (!tbody) return;

    if (state.newCase.prescriptions.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 24px; color: #64748b;">
            Hali retsept qo'shilmagan. Yuqoridagi formadan qo'shing yoki tayyor protokollarni bosing.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = state.newCase.prescriptions.map((rx, idx) => `
      <tr style="border-bottom: 1px solid rgba(255,255,255,0.06);">
        <td style="padding: 8px 12px; font-weight: 700; color: #38bdf8;">${idx + 1}</td>
        <td style="padding: 8px 12px;"><strong style="color: #f1f5f9;">${rx.medication_name}</strong></td>
        <td style="padding: 8px 12px; color: #a5f3fc; font-family: monospace;">${rx.dosage}</td>
        <td style="padding: 8px 12px;"><span class="status-pill status-completed" style="font-size: 0.72rem;">${rx.route}</span></td>
        <td style="padding: 8px 12px; font-weight: 600;">${rx.duration_days} kun</td>
        <td style="padding: 8px 12px; color: #cbd5e1; font-size: 0.78rem;">${rx.frequency}</td>
        <td style="padding: 8px 12px; text-align: center;">
          <button type="button" class="btn-doc-danger" style="padding: 2px 8px; font-size: 0.7rem;" onclick="window.FMH_Doctor.removeModalPrescriptionRow(${idx})" title="O'chirish">
            <i class="fas fa-trash"></i>
          </button>
        </td>
      </tr>
    `).join('');
  }

  function applyModalPreset(presetKey) {
    let presetItems = [];
    if (presetKey === 'detox') {
      presetItems = [
        { medication_name: 'Reosorbilakt 400ml', form: 'Infuzion flakon', dosage: '400 ml', route: 'v/i tomchilab', duration_days: 3, frequency: '1 marta ertalab, k/k sekin' },
        { medication_name: 'Natriy Xlorid 0.9% 400ml', form: 'Infuzion flakon', dosage: '400 ml', route: 'v/i tomchilab', duration_days: 3, frequency: '1 marta kunduzi, k/k' },
        { medication_name: 'Magniy sulfat 25% 10ml', form: 'Ampula', dosage: '10 ml', route: 'v/i tomchilab', duration_days: 3, frequency: '1 marta NaCl bilan birga' },
        { medication_name: 'Askorbin kislotasi (Vit C) 5%', form: 'Ampula', dosage: '4 ml', route: 'v/i tomchilab', duration_days: 3, frequency: '1 marta tomchilab' },
        { medication_name: 'Piratsetam 20% 10ml', form: 'Ampula', dosage: '10 ml', route: 'v/i tomchilab', duration_days: 5, frequency: '1 marta ertalab' }
      ];
    } else if (presetKey === 'abstinence_heavy') {
      presetItems = [
        { medication_name: 'Reamberin 1.5% 400ml', form: 'Infuzion flakon', dosage: '400 ml', route: 'v/i tomchilab', duration_days: 4, frequency: '1 marta ertalab, k/k' },
        { medication_name: 'Diazepam (Relanium) 0.5% 2ml', form: 'Ampula', dosage: '2 ml', route: 'v/m inyeksiya', duration_days: 3, frequency: '2 marta (ertalab/kechqurun)' },
        { medication_name: 'Tiamin xlorid (B1) 5% 1ml', form: 'Ampula', dosage: '2 ml', route: 'v/m inyeksiya', duration_days: 5, frequency: '1 marta mushak ichiga' },
        { medication_name: 'Piridoksin (B6) 5% 1ml', form: 'Ampula', dosage: '2 ml', route: 'v/m inyeksiya', duration_days: 5, frequency: '1 marta mushak ichiga' },
        { medication_name: 'Metoklopramid (Serukal) 2ml', form: 'Ampula', dosage: '2 ml', route: 'v/m inyeksiya', duration_days: 2, frequency: 'Ko\'ngil aynaganda v/m' }
      ];
    } else if (presetKey === 'sedation') {
      presetItems = [
        { medication_name: 'Diazepam 10mg / 2ml', form: 'Ampula', dosage: '2 ml', route: 'v/m inyeksiya', duration_days: 3, frequency: '1 marta uyqudan 30 daqiqa oldin' },
        { medication_name: 'Fenazepam 1mg', form: 'Tabletkalar', dosage: '1 tab (1mg)', route: 'per os', duration_days: 5, frequency: 'Kechqurun uyqudan oldin' },
        { medication_name: 'Karbamazepin 200mg', form: 'Tabletkalar', dosage: '100 mg (1/2 tab)', route: 'per os', duration_days: 7, frequency: 'Kechqurun qabul qilish' }
      ];
    } else if (presetKey === 'hepatoprotect') {
      presetItems = [
        { medication_name: 'Essentiale Forte N 5ml', form: 'Ampula', dosage: '5 ml', route: 'v/i oqim bilan', duration_days: 5, frequency: '1 marta sekin v/i oqimli' },
        { medication_name: 'Geptral (Ademetionin) 400mg', form: 'Flakon', dosage: '400 mg', route: 'v/i tomchilab', duration_days: 5, frequency: '1 marta fiziologik eritmada' },
        { medication_name: 'Glukoza 5% 400ml + Insulin 4TB', form: 'Infuzion flakon', dosage: '400 ml', route: 'v/i tomchilab', duration_days: 3, frequency: '1 marta tushlikda' }
      ];
    }

    presetItems.forEach(item => {
      state.newCase.prescriptions.push({
        id: 'RX-' + Math.floor(Math.random() * 90000 + 10000),
        status: 'active',
        timing: 'Klinik protokol',
        instructions: item.frequency,
        ...item
      });
    });

    renderModalPrescriptions();
    showToast(`⚡ Protokol bo'yicha ${presetItems.length} ta dori ro'yxatga kiritildi!`, "success");
  }

  async function handleCaseSubmit(e) {
    if (e && e.preventDefault) e.preventDefault();

    if (!state.authenticatedDoctor) {
      showToast("Iltimos, avval shifokor kabinetiga kiring!", "danger");
      showDoctorAuthModal();
      return;
    }

    const name = document.getElementById('case-patient-name')?.value.trim();
    const dob = document.getElementById('case-patient-dob')?.value.trim();
    const gender = document.getElementById('case-patient-gender')?.value || 'Erkak';
    const phone = document.getElementById('case-patient-phone')?.value.trim();
    const address = document.getElementById('case-patient-address')?.value.trim() || '';
    const passport = document.getElementById('case-patient-passport')?.value.trim() || '';
    const relative = document.getElementById('case-patient-relative')?.value.trim() || '';

    const complaints = document.getElementById('case-complaints')?.value.trim();
    const anamnesisMorbi = document.getElementById('case-anamnesis-morbi')?.value.trim() || '';
    const anamnesisVitae = document.getElementById('case-anamnesis-vitae')?.value.trim() || '';
    const allergies = document.getElementById('case-allergies')?.value.trim() || "Yo'q";
    const somaticStatus = `AQB: ${document.getElementById('case-vital-bp')?.value || '120/80'}, Puls: ${document.getElementById('case-vital-pulse')?.value || '76'}, Temp: ${document.getElementById('case-vital-temp')?.value || '36.6'}, SpO2: ${document.getElementById('case-vital-spo2')?.value || '98%'}`;
    const psychiatricStatus = document.getElementById('case-mental-status')?.value.trim() || '';
    const icdCode = document.getElementById('case-icd-code')?.value.trim() || 'F10.2';
    const diagnosis = document.getElementById('case-diagnosis')?.value.trim();

    if (!name || !dob || !phone || !complaints || !diagnosis) {
      showToast("Iltimos, barcha majburiy klinik maydonlarni to'ldiring!", "warning");
      return;
    }

    let birthYear = 1990;
    const yearMatch = dob.match(/\b(19\d\d|20\d\d)\b/);
    if (yearMatch) birthYear = parseInt(yearMatch[1]);

    const bedSelect = document.getElementById('case-bed-select');
    const selectedBedOption = bedSelect && bedSelect.selectedIndex >= 0 ? bedSelect.options[bedSelect.selectedIndex] : null;
    const bedId = bedSelect?.value || null;
    const roomType = document.getElementById('case-room-type')?.value || 'Standart';
    const stayDays = parseInt(document.getElementById('case-stay-days')?.value) || 7;

    const payload = {
      doctor_id: state.authenticatedDoctor.staff_id,
      doctor_name: state.authenticatedDoctor.name,
      patient_name: name,
      patient_phone: phone,
      gender: gender.toLowerCase() === 'ayol' ? 'female' : 'male',
      birth_year: birthYear,
      address: address,
      emergency_contact: relative,
      allergic_status: allergies,
      consultation_type: state.newCase.intakeType,
      inpatient_details: state.newCase.intakeType === 'inpatient' ? {
        bed_id: bedId,
        room_number: selectedBedOption ? selectedBedOption.getAttribute('data-room') : '11',
        bed_number: selectedBedOption ? selectedBedOption.getAttribute('data-bed') : '1A',
        program_type: `${roomType} Statsionar davolash kursi`,
        start_date: new Date().toISOString().split('T')[0],
        end_date: new Date(Date.now() + stayDays * 86400000).toISOString().split('T')[0],
        daily_price: roomType === 'VIP' ? 1100000 : 720000
      } : null,
      anamnesis: {
        complaints: complaints,
        anamnesis_morbi: anamnesisMorbi,
        anamnesis_vitae: anamnesisVitae,
        allergic_status: allergies,
        somatic_status: somaticStatus,
        psychiatric_status: psychiatricStatus,
        diagnosis_primary: diagnosis,
        diagnosis_secondary: passport ? `Pasport/PINFL: ${passport}` : '',
        icd10_code: icdCode
      },
      prescriptions: state.newCase.prescriptions
    };

    const submitBtn = document.getElementById('btn-case-submit');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saqlanmoqda...';
    }

    try {
      const res = await fetch('/api/doctor/consultation-case', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      let resData = {};
      try { resData = await res.json(); } catch (e) {}

      if (res.ok && (resData.success || resData.patient_id)) {
        const patientId = resData.patient_id;
        const patientCode = resData.patient_code;

        const newPatient = {
          id: patientId,
          patient_code: patientCode,
          full_name: name,
          gender: payload.gender,
          birth_year: birthYear,
          phone: phone,
          address: address,
          medical_allergies: allergies,
          doctor_id: state.authenticatedDoctor.staff_id,
          doctor_name: state.authenticatedDoctor.name,
          consulting_doctor_id: state.authenticatedDoctor.staff_id,
          consulting_doctor_name: state.authenticatedDoctor.name,
          status: 'active',
          active_admission: state.newCase.intakeType === 'inpatient' ? {
            admission_id: resData.admission_id,
            room_number: payload.inpatient_details.room_number,
            bed_code: payload.inpatient_details.bed_number,
            doctor_id: state.authenticatedDoctor.staff_id,
            doctor_name: state.authenticatedDoctor.name,
            program_type: payload.inpatient_details.program_type
          } : null
        };

        state.anamnesisMap[patientId] = {
          patient_id: patientId,
          admission_id: resData.admission_id,
          doctor_id: state.authenticatedDoctor.staff_id,
          complaints: complaints,
          anamnesis_morbi: anamnesisMorbi,
          anamnesis_vitae: anamnesisVitae,
          allergic_status: allergies,
          somatic_status: somaticStatus,
          psychiatric_status: psychiatricStatus,
          diagnosis_primary: diagnosis,
          diagnosis_secondary: passport ? `Pasport/PINFL: ${passport}` : '',
          icd10_code: icdCode
        };
        localStorage.setItem(STORAGE_KEYS.ANAMNESIS, JSON.stringify(state.anamnesisMap));

        if (state.newCase.prescriptions.length > 0) {
          state.prescriptionsMap[patientId] = state.newCase.prescriptions.map(rx => ({
            ...rx,
            doctor_name: state.authenticatedDoctor.name
          }));
          localStorage.setItem(STORAGE_KEYS.PRESCRIPTIONS, JSON.stringify(state.prescriptionsMap));
        }

        state.patients.unshift(newPatient);
        filterPatients(state.currentFilter);
        selectPatient(newPatient);

        closeNewConsultationModal();
        showToast(`✅ Bemor "${name}" uchun kasallik varaqasi va ${state.newCase.prescriptions.length} ta retsept muvaffaqiyatli saqlandi!`, "success");

        if (state.newCase.prescriptions.length > 0) {
          setTimeout(() => {
            if (confirm(`Bemor "${name}" uchun rasmiy muolaja varaqasini (List Naznacheniy / A4) hozir chop etasizmi?`)) {
              openOfficialDocModal('prescriptions');
            }
          }, 300);
        }

        updateKPIs();
      } else {
        showToast(resData.error || "Xatolik yuz berdi. Qayta urinib ko'ring.", "danger");
      }
    } catch (err) {
      console.error("Consultation case error:", err);
      showToast("Server bilan bog'lanishda xatolik!", "danger");
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Tasdiqlash & Kasallik Varaqasini Ochish';
      }
    }
  }

  // Global window exposure
  window.FMH_Doctor = {
    init,
    toggleTheme,
    selectPatientById,
    filterPatients,
    clearSearch,
    quickJump,
    switchTab,
    saveAnamnesis,
    saveEpicrisis,
    applyAnamnesisTemplate,
    applyDiagnosisPreset,
    addPrescription,
    applyPresetProtocol,
    setRxField,
    filterRxTable,
    toggleRxStatus,
    deletePrescription,
    deleteCurrentPatient,
    addDailyNote,
    setNormalVitals,
    appendDynamicsPhrase,
    setTreatmentPhrase,
    autoGenerateEpicrisis,
    appendHomeRx,
    setPsychoRec,
    onDrugNameInput,
    openClinicMedsModal,
    closeClinicMedsModal,
    onClinicMedsFilter,
    setClinicCat,
    fillFormWithMed,
    prescribeClinicMed,
    openOfficialDocModal,
    closeOfficialDocModal,
    renderOfficialDocumentPreview,
    printOfficialDocument,
    printPrescriptionSheet: () => printOfficialDocument('prescriptions'),
    printEpicrisis: () => printOfficialDocument('epicrisis'),
    downloadPDF,

    // Doctor Auth & Identity
    checkDoctorAuth,
    showDoctorAuthModal,
    hideDoctorAuthModal,
    selectAuthPreset,
    handleAuthSubmit,
    logoutDoctor,
    updateDoctorIdentityDisplay,

    // Consultation & Case Sheet Engine
    openNewConsultationModal,
    closeNewConsultationModal,
    toggleIntakeType,
    loadBedOptionsForModal,
    switchCaseStep,
    nextCaseStep,
    prevCaseStep,
    addModalPrescriptionRow,
    removeModalPrescriptionRow,
    renderModalPrescriptions,
    applyModalPreset,
    handleCaseSubmit
  };

  // Auto-init on DOM ready (with readyState check to run if already loaded)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
