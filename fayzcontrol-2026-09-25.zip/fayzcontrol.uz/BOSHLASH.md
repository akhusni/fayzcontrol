# Fayz Control — yangi mashinada ishga tushirish

Bu arxivda **tizimning o'zi** bor. Xodimlarning parollari bu yerda **yo'q** —
ular alohida Excel faylida (`FMH_hisoblar_va_parollar.xlsx`) va alohida
yuborilishi kerak.

---

## 1. Talablar

- Python 3.9 yoki undan yangi
- MySQL 8.0
- `python3 -m pip install PyMySQL reportlab`

## 2. Bazani yaratish

```bash
mysql -u root -p -e "CREATE DATABASE fayzhouse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p -e "CREATE USER 'fayzhouse'@'127.0.0.1' IDENTIFIED BY '<kuchli-parol>';"
mysql -u root -p -e "GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES, LOCK TABLES ON fayzhouse.* TO 'fayzhouse'@'127.0.0.1';"

mysql -u fayzhouse -p fayzhouse < data/schema.mysql.sql   # jadvallar va view'lar
mysql -u fayzhouse -p fayzhouse < data/seed_data.sql      # 12 xona, 14 o'rin, xodimlar, katalog
```

Bazaga **klinik ma'lumot qo'shilmagan** — bemorlar, yotishlar, to'lovlar
bo'sh. Faqat xonalar, o'rinlar va kataloglar.

## 3. Ulanish sozlamasi

```bash
cp db_config.example.json db_config.json
chmod 600 db_config.json
```
`db_config.json` ichiga yuqorida yaratgan parolni yozing. **Bu fayl hech qachon
arxivga yoki gitga qo'shilmasin.**

## 4. Ishga tushirish

```bash
python3 install.py          # tekshiradi (yaratmaydi)
python3 server.py 3000
```

Brauzer: `http://localhost:3000` → kirish sahifasi.

Doimiy ishlatish (systemd + Nginx): **`DEPLOYMENT_AND_DOMAINS.md`, 4-bo'lim.**
U yerda `X-Forwarded-Proto` va `X-Real-IP` sarlavhalari **majburiy** ekani
tushuntirilgan.

## 5. Birinchi kirish

Excel faylidagi bir martalik parollardan foydalaning. Har bir hisob birinchi
kirishda **o'z parolini o'rnatishni majburan so'raydi** — shundan keyin
Exceldagi parol ishlamaydi.

---

## 6. Ishga tushirishdan oldin bajarilishi SHART

### a) Zaxira nusxani yoqing

Skriptlar tayyor va sinovdan o'tgan, lekin **o'z-o'zidan ishlamaydi**:

```bash
./scripts/backup.sh --verify            # qo'lda bir marta sinab ko'ring
sudo cp scripts/fayzcontrol-backup.cron /etc/cron.d/fayzcontrol-backup
# ichidagi yo'l va foydalanuvchini o'z serveringizga moslang
```

Zaxira **bazadan boshqa diskda** turishi kerak.

### b) Tiklashni bir marta sinab ko'ring

Tekshirilmagan zaxira zaxira emas:

```bash
FMH_ADMIN_DB_USER=root FMH_ADMIN_DB_PASSWORD=... ./scripts/restore-test.sh
```

Arxivni **alohida vaqtinchalik bazaga** tiklaydi, jonli baza bilan
solishtiradi va o'chiradi. Jonli bazaga tegmaydi. Natija:
`RESULT: the archive reproduces the database exactly`.

### c) Excel faylini tarqatgandan keyin o'chiring

Uni pochtada yoki messenjerda saqlab qo'ymang.

---

## 7. Sayt bilan integratsiya

`fayzmedical.uz` dagi yozilish formasi **`/api/public/appointment-request`**
ga yuborishi kerak (avvalgi `/api/reception/appointment` emas — u endi
avtorizatsiya talab qiladi). To'liq ko'rsatma, maydonlar ro'yxati, spamdan
himoya va CORS sozlamasi: **`DEPLOYMENT_AND_DOMAINS.md`, 5-bo'lim.**

Arizalar qabulxonadagi **"Saytdan So'rovlar"** tabida ko'rinadi. Xodim
"Qabul qilish" bosmaguncha bemor kartasi ochilmaydi.

## 8. Hali yo'q narsalar

- Farmatsevt va oshxona uchun alohida sahifa.
- `building_management.html` bronlarni hali `localStorage` da saqlaydi.
- Sessiyalar xotirada — server qayta ishga tushsa, hamma qaytadan kiradi.

Batafsil: `CHANGES.md` (nima qilingani) va `README.md`.
